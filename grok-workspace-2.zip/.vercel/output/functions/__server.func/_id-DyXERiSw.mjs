import { i as __toESM } from "./_runtime.mjs";
import { n as require_react } from "./_libs/@radix-ui/react-compose-refs+[...].mjs";
import { x as useNavigate } from "./_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "./_libs/radix-ui__react-context+react.mjs";
import { n as toast } from "./_libs/sonner.mjs";
import { n as Route } from "./_ssr/router-Dtl68I8g.mjs";
import { a as CHANNELS, f as cn, h as useSession, i as Button, l as KNOB_META, m as useLibrary, n as AMP_TYPES, o as CHANNEL_LABEL, p as newToneDraft, r as AppShell, t as AMP_LABEL } from "./_ssr/app-shell-BntSRKpV.mjs";
import { n as Textarea, t as Input } from "./_ssr/input-CM_DLr3M.mjs";
import { n as FxToggleRow } from "./_ssr/fx-chain-BSglswkC.mjs";
import { t as AmpKnob } from "./_ssr/amp-knob-No3XKkbx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_id-DyXERiSw.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Select({ className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
		className: cn("h-11 w-full appearance-none rounded-md bg-raised bg-[length:12px] bg-[right_12px_center] bg-no-repeat px-3 pr-9 text-sm text-fg shadow-[0_0_0_1px_rgb(255_255_255/0.08)]", "focus-visible:outline-none focus-visible:shadow-[0_0_0_2px_color-mix(in_oklab,var(--color-accent)_50%,transparent)]", className),
		style: { backgroundImage: "url(\"data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='12' height='8' viewBox='0 0 12 8'><path fill='%239a9690' d='M1 1l5 5 5-5'/></svg>\")" },
		...props,
		children
	});
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "grid gap-1.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-display text-[11px] uppercase tracking-[0.16em] text-muted",
			children: label
		}), children]
	});
}
var BOOSTER_TYPES = [
	"Clean Boost",
	"Treble Boost",
	"Mid Boost",
	"Blues Drive",
	"Overdrive",
	"T-Scream",
	"Turbo OD",
	"Distortion",
	"Fat DS",
	"Metal DS",
	"Oct Fuzz",
	"Blues OD"
];
var MOD_TYPES = [
	"Chorus",
	"Flanger",
	"Phaser",
	"Uni-V",
	"Tremolo",
	"Vibrato",
	"Rotary",
	"Ring Mod",
	"Slicer"
];
var FX_TYPES = [
	"Compressor",
	"T.Wah",
	"Auto Wah",
	"Octave",
	"Pitch Shifter",
	"Harmonist",
	"Guitar Sim",
	"Slow Gear",
	"Defretter",
	"Wav Synth"
];
var DELAY_TYPES = [
	"Digital",
	"Analog",
	"Tape Echo",
	"Reverse",
	"Modulation",
	"SDE-3000",
	"Warm",
	"Slap"
];
var REVERB_TYPES = [
	"Ambience",
	"Room",
	"Hall",
	"Plate",
	"Spring",
	"Modulate",
	"Cathedral"
];
var TAGS = [
	"gig",
	"studio",
	"practice",
	"blues",
	"rock",
	"metal",
	"country",
	"funk",
	"ambient",
	"acoustic",
	"lead",
	"rhythm"
];
var TYPE_OPTIONS = {
	booster: BOOSTER_TYPES,
	mod: MOD_TYPES,
	fx: FX_TYPES,
	delay: DELAY_TYPES,
	reverb: REVERB_TYPES
};
function ToneForm({ tone, onChange }) {
	function patchKnobs(key, value) {
		onChange({ knobs: {
			...tone.knobs,
			[key]: value
		} });
	}
	function toggleFx(key) {
		onChange({ fx: {
			...tone.fx,
			[key]: {
				...tone.fx[key],
				on: !tone.fx[key].on
			}
		} });
	}
	function setFxType(key, type) {
		onChange({ fx: {
			...tone.fx,
			[key]: {
				...tone.fx[key],
				type
			}
		} });
	}
	function toggleTag(tag) {
		onChange({ tags: tone.tags.includes(tag) ? tone.tags.filter((t) => t !== tag) : [...tone.tags, tag] });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Name",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: tone.name,
					onChange: (e) => onChange({ name: e.target.value })
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Song / use",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: tone.song,
					placeholder: "Where this tone lives",
					onChange: (e) => onChange({ song: e.target.value })
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Notes",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					value: tone.notes,
					placeholder: "Pickup, capo, extra stomps…",
					onChange: (e) => onChange({ notes: e.target.value })
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Amp type",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
						value: tone.ampType,
						onChange: (e) => onChange({ ampType: e.target.value }),
						children: AMP_TYPES.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: a,
							children: AMP_LABEL[a]
						}, a))
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Variation",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: String(tone.variation),
						onChange: (e) => onChange({ variation: Number(e.target.value) }),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "1",
							children: "Variation 1"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "2",
							children: "Variation 2"
						})]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Amp memory",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					value: String(tone.channel),
					onChange: (e) => onChange({ channel: Number(e.target.value) }),
					children: CHANNELS.map((ch) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: ch,
						children: CHANNEL_LABEL[ch]
					}, ch))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-3 font-display text-[11px] uppercase tracking-[0.16em] text-muted",
				children: "Panel knobs"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-1 overflow-x-auto pb-1",
				children: KNOB_META.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AmpKnob, {
					label: k.label,
					value: tone.knobs[k.key],
					onChange: (v) => patchKnobs(k.key, v)
				}, k.key))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-3 font-display text-[11px] uppercase tracking-[0.16em] text-muted",
					children: "Effects"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FxToggleRow, {
					fx: tone.fx,
					onToggle: toggleFx
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 grid gap-3",
					children: [[
						"booster",
						"mod",
						"fx",
						"delay",
						"reverb"
					].map((key) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: `${key} type`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
							value: tone.fx[key].type,
							onChange: (e) => setFxType(key, e.target.value),
							children: TYPE_OPTIONS[key].map((opt) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: opt,
								children: opt
							}, opt))
						})
					}, key)), tone.fx.delay.on ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Delay time (ms)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							min: 20,
							max: 2e3,
							value: tone.fx.delay.timeMs,
							onChange: (e) => onChange({ fx: {
								...tone.fx,
								delay: {
									...tone.fx.delay,
									timeMs: Number(e.target.value) || 0
								}
							} })
						})
					}) : null]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-2 font-display text-[11px] uppercase tracking-[0.16em] text-muted",
				children: "Tags"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-1.5",
				children: TAGS.map((tag) => {
					const on = tone.tags.includes(tag);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => toggleTag(tag),
						className: cn("h-9 rounded-full px-3 text-sm transition-colors duration-150", on ? "bg-accent text-accent-fg" : "bg-raised text-muted"),
						children: tag
					}, tag);
				})
			})] })
		]
	});
}
function ToneEditor() {
	const { id } = Route.useParams();
	const navigate = useNavigate();
	const tones = useLibrary((s) => s.tones);
	const upsertTone = useLibrary((s) => s.upsertTone);
	const deleteTone = useLibrary((s) => s.deleteTone);
	const sendTone = useSession((s) => s.sendTone);
	const isNew = id === "new";
	const existing = tones.find((t) => t.id === id);
	const [draft, setDraft] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (isNew) setDraft(newToneDraft());
		else if (existing) setDraft(existing);
	}, [
		id,
		isNew,
		existing
	]);
	if (!isNew && !existing) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-muted",
		children: "That tone is gone."
	}) });
	if (!draft) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-muted",
		children: "Loading recipe…"
	}) });
	function patch(partial) {
		setDraft((d) => d ? {
			...d,
			...partial
		} : d);
	}
	function save() {
		if (!draft) return;
		const name = draft.name.trim() || "Untitled tone";
		upsertTone({
			...draft,
			name
		});
		toast.success("Saved to library");
		if (isNew) navigate({
			to: "/tone/$id",
			params: { id: draft.id }
		});
	}
	async function send() {
		if (!draft) return;
		save();
		try {
			await sendTone(draft);
			toast.success(`Recalled ${CHANNEL_LABEL[draft.channel]}`);
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Send failed");
		}
	}
	function remove() {
		if (!draft) return;
		if (isNew) {
			navigate({ to: "/" });
			return;
		}
		deleteTone(draft.id);
		toast.message("Tone removed");
		navigate({ to: "/" });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 flex items-center justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-[11px] uppercase tracking-[0.22em] text-muted",
				children: "Recipe"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-xl font-medium",
				children: isNew ? "New tone" : draft.name
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "sm",
				onClick: save,
				children: "Save"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToneForm, {
			tone: draft,
			onChange: patch
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 grid gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => void send(),
				children: "Send to amp"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				onClick: remove,
				children: isNew ? "Discard" : "Delete tone"
			})]
		})
	] });
}
//#endregion
export { ToneEditor as component };
