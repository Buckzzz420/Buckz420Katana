import { i as __toESM } from "./_runtime.mjs";
import { n as require_react } from "./_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "./_libs/radix-ui__react-context+react.mjs";
import { d as ChevronLeft, u as ChevronRight } from "./_libs/lucide-react.mjs";
import { n as toast } from "./_libs/sonner.mjs";
import { r as Route$1 } from "./_ssr/router-Dtl68I8g.mjs";
import { f as cn, h as useSession, i as Button, m as useLibrary, o as CHANNEL_LABEL, r as AppShell, t as AMP_LABEL } from "./_ssr/app-shell-BntSRKpV.mjs";
import { t as Input } from "./_ssr/input-CM_DLr3M.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_id-B8kYQbss.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function SetlistPlay() {
	const { id } = Route$1.useParams();
	const setlists = useLibrary((s) => s.setlists);
	const tones = useLibrary((s) => s.tones);
	const updateSetlist = useLibrary((s) => s.updateSetlist);
	const sendTone = useSession((s) => s.sendTone);
	const transport = useSession((s) => s.transport);
	const [index, setIndex] = (0, import_react.useState)(0);
	const setlist = setlists.find((s) => s.id === id);
	const items = (0, import_react.useMemo)(() => setlist ? setlist.toneIds.map((tid) => tones.find((t) => t.id === tid)).filter((t) => Boolean(t)) : [], [setlist, tones]);
	const current = items[index];
	async function go(next) {
		if (!items.length) return;
		const wrapped = (next + items.length) % items.length;
		setIndex(wrapped);
		const tone = items[wrapped];
		if (!tone) return;
		try {
			await sendTone(tone);
			toast.success(`${tone.name} → ${CHANNEL_LABEL[tone.channel]}${transport === "simulator" ? " (demo)" : ""}`);
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Send failed");
		}
	}
	function addTone(toneId) {
		if (!setlist) return;
		if (setlist.toneIds.includes(toneId)) return;
		updateSetlist(setlist.id, { toneIds: [...setlist.toneIds, toneId] });
	}
	function removeAt(i) {
		if (!setlist) return;
		updateSetlist(setlist.id, { toneIds: setlist.toneIds.filter((_, idx) => idx !== i) });
		setIndex((n) => Math.max(0, Math.min(n, setlist.toneIds.length - 2)));
	}
	if (!setlist) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-muted",
		children: "Setlist missing."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/setlists",
		className: "mt-3 inline-block text-sm",
		children: "Back"
	})] });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
			value: setlist.name,
			onChange: (e) => updateSetlist(setlist.id, { name: e.target.value }),
			className: "font-medium",
			"aria-label": "Setlist name"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
			value: setlist.venue,
			placeholder: "Venue",
			className: "mt-2",
			onChange: (e) => updateSetlist(setlist.id, { venue: e.target.value }),
			"aria-label": "Venue"
		}),
		current ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-5 rounded-xl bg-surface p-5 text-center shadow-[0_0_0_1px_rgb(255_255_255/0.08)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-display text-[11px] uppercase tracking-[0.22em] text-muted",
					children: [
						index + 1,
						" / ",
						items.length,
						" · ",
						CHANNEL_LABEL[current.channel]
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-2 text-2xl font-medium leading-snug break-words",
					children: current.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-sm text-muted",
					children: [
						AMP_LABEL[current.ampType],
						" · V",
						current.variation,
						current.song ? ` · ${current.song}` : ""
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "secondary",
						onClick: () => void go(index - 1),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, {}), "Prev"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: () => void go(index + 1),
						children: ["Next", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, {})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "mt-2 w-full",
					variant: "led",
					onClick: () => void go(index),
					children: "Send this tone"
				})
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-6 text-sm text-muted",
			children: "Add tones below, then step through them on the gig."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
			className: "mt-6 font-display text-[11px] uppercase tracking-[0.18em] text-muted",
			children: "Order"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
			className: "mt-2 grid gap-1.5",
			children: items.map((tone, i) => tone ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: cn("flex min-h-12 items-center gap-3 rounded-md px-3", i === index ? "bg-led/15" : "bg-raised"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "min-w-0 flex-1 text-left",
					onClick: () => void go(i),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block truncate text-sm font-medium",
						children: tone.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-muted",
						children: CHANNEL_LABEL[tone.channel]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "text-xs text-muted",
					onClick: () => removeAt(i),
					children: "Drop"
				})]
			}, `${tone.id}-${i}`) : null)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
			className: "mt-6 font-display text-[11px] uppercase tracking-[0.18em] text-muted",
			children: "Add from library"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-2 grid gap-1.5",
			children: tones.map((tone) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => addTone(tone.id),
				className: "flex min-h-11 w-full items-center justify-between rounded-md bg-surface px-3 text-left text-sm shadow-[0_0_0_1px_rgb(255_255_255/0.06)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "truncate",
					children: tone.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs text-muted",
					children: "Add"
				})]
			}) }, tone.id))
		})
	] });
}
//#endregion
export { SetlistPlay as component };
