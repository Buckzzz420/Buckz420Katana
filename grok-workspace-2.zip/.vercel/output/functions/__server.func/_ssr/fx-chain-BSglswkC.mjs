import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { c as FX_ORDER, f as cn, s as FX_LABEL } from "./app-shell-BntSRKpV.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/fx-chain-BSglswkC.js
var import_jsx_runtime = require_jsx_runtime();
function FxChainPips({ fx, compact }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex items-center gap-1",
		children: FX_ORDER.map((key) => {
			const on = fx[key].on;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				title: `${FX_LABEL[key]}${on ? " on" : " off"}`,
				className: cn("rounded-full font-display uppercase tracking-wider", compact ? "size-1.5" : "px-1.5 py-0.5 text-[9px]", on ? compact ? "bg-led" : "bg-led/20 text-fg" : compact ? "bg-border" : "bg-raised text-subtle"),
				children: compact ? null : FX_LABEL[key]
			}, key);
		})
	});
}
function FxToggleRow({ fx, onToggle }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid grid-cols-5 gap-1.5",
		children: FX_ORDER.map((key) => {
			const on = fx[key].on;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => onToggle(key),
				className: cn("flex min-h-11 flex-col items-center justify-center gap-1.5 rounded-md px-1 transition-[background-color,box-shadow] duration-150 ease-out", on ? "bg-led/15 shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-led)_50%,transparent)]" : "bg-raised shadow-[0_0_0_1px_rgb(255_255_255/0.06)]"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("led-pip", on && "on") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-display text-[10px] uppercase tracking-[0.16em] text-fg",
					children: FX_LABEL[key]
				})]
			}, key);
		})
	});
}
//#endregion
export { FxToggleRow as n, FxChainPips as t };
