import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { g as webMidiSupported, h as useSession, i as Button, m as useLibrary, r as AppShell, u as bluetoothSupported } from "./app-shell-BntSRKpV.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/more-C1ly6qjy.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function MorePage() {
	const tones = useLibrary((s) => s.tones);
	const setlists = useLibrary((s) => s.setlists);
	const replaceAll = useLibrary((s) => s.replaceAll);
	const resetFactory = useLibrary((s) => s.resetFactory);
	const log = useSession((s) => s.log);
	const transport = useSession((s) => s.transport);
	const deviceName = useSession((s) => s.deviceName);
	const setConnectOpen = useSession((s) => s.setConnectOpen);
	const fileRef = (0, import_react.useRef)(null);
	function exportLibrary() {
		const blob = new Blob([JSON.stringify({
			version: 1,
			tones,
			setlists
		}, null, 2)], { type: "application/json" });
		const url = URL.createObjectURL(blob);
		const a = document.createElement("a");
		a.href = url;
		a.download = "katana-case-library.json";
		a.click();
		URL.revokeObjectURL(url);
		toast.success("Library exported");
	}
	async function onImport(file) {
		if (!file) return;
		try {
			const parsed = JSON.parse(await file.text());
			if (!Array.isArray(parsed.tones)) throw new Error("No tones in file");
			replaceAll(parsed.tones, Array.isArray(parsed.setlists) ? parsed.setlists : []);
			toast.success(`Imported ${parsed.tones.length} tones`);
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Import failed");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-[11px] uppercase tracking-[0.22em] text-muted",
			children: "Setup"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "text-xl font-medium",
			children: "More"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-5 rounded-lg bg-surface p-4 shadow-[0_0_0_1px_rgb(255_255_255/0.08)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-medium",
					children: "Amp"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-muted",
					children: [
						deviceName,
						" · ",
						transport === "simulator" ? "demo" : transport
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-xs text-subtle",
					children: [
						"Bluetooth ",
						bluetoothSupported() ? "ready" : "not in this browser",
						" · MIDI",
						" ",
						webMidiSupported() ? "ready" : "not in this browser"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "mt-3 w-full",
					variant: "secondary",
					onClick: () => setConnectOpen(true),
					children: "Open connection"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-3 rounded-lg bg-surface p-4 shadow-[0_0_0_1px_rgb(255_255_255/0.08)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-medium",
				children: "Bluetooth MIDI"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
				className: "mt-2 list-decimal space-y-1.5 pl-4 text-sm text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Install the BOSS BT-DUAL in the Katana Gen 3 Bluetooth port." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Power on. Tap the adaptor once — LED blinks blue slowly (MIDI, not audio)." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "On Android, use Chrome. Do not pair KATANA 3 MIDI in system Bluetooth." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Add this app to your home screen, then Connect from the header pill." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Sending a tone recalls the mapped Panel / CH1–CH8 memory on the amp." })
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-3 rounded-lg bg-surface p-4 shadow-[0_0_0_1px_rgb(255_255_255/0.08)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-medium",
					children: "Library file"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "JSON backup of tones and setlists on this device."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						onClick: exportLibrary,
						children: "Export"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						onClick: () => fileRef.current?.click(),
						children: "Import"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					ref: fileRef,
					type: "file",
					accept: "application/json",
					className: "hidden",
					onChange: (e) => void onImport(e.target.files?.[0])
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "mt-2 w-full",
					variant: "ghost",
					onClick: () => {
						resetFactory();
						toast.message("Factory library restored");
					},
					children: "Restore factory tones"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-3 rounded-lg bg-surface p-4 shadow-[0_0_0_1px_rgb(255_255_255/0.08)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-medium",
					children: "MIDI log"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "Last messages this session."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-3 max-h-56 space-y-2 overflow-y-auto font-mono text-[11px] leading-relaxed text-muted",
					children: [log.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "No traffic yet. Send a tone from the library." }) : null, log.map((ev) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-subtle",
							children: ev.dir === "out" ? "TX" : "RX"
						}),
						" ",
						ev.label,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "truncate text-subtle",
							children: ev.hex
						})
					] }, ev.id))]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-6 pb-4 text-center text-xs text-subtle",
			children: "Katana Case is an unofficial companion. Katana and BOSS are trademarks of Roland Corporation. Store channel memories on the amp; this app recalls them over MIDI."
		})
	] });
}
//#endregion
export { MorePage as component };
