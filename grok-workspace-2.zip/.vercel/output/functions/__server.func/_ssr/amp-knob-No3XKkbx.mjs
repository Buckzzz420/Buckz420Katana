import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { d as clamp, f as cn } from "./app-shell-BntSRKpV.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/amp-knob-No3XKkbx.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AmpKnob({ label, value, onChange, disabled }) {
	const live = (0, import_react.useRef)(value);
	live.current = value;
	const lastY = (0, import_react.useRef)(0);
	const dragging = (0, import_react.useRef)(false);
	const angle = -135 + clamp(value, 0, 100) / 100 * 270;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex w-[4.5rem] flex-col items-center gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			disabled,
			"aria-label": `${label} ${Math.round(value)}`,
			className: cn("relative size-14 touch-none rounded-full bg-raised shadow-[0_0_0_1px_rgb(255_255_255/0.1),inset_0_1px_0_rgb(255_255_255/0.08)]", "transition-transform duration-150 ease-out active:scale-[0.96]", disabled && "opacity-50"),
			onPointerDown: (e) => {
				dragging.current = true;
				lastY.current = e.clientY;
				e.currentTarget.setPointerCapture(e.pointerId);
			},
			onPointerMove: (e) => {
				if (!dragging.current) return;
				const next = clamp(live.current - (e.clientY - lastY.current) * .45, 0, 100);
				lastY.current = e.clientY;
				live.current = next;
				onChange(next);
			},
			onPointerUp: () => {
				dragging.current = false;
			},
			onPointerCancel: () => {
				dragging.current = false;
			},
			onKeyDown: (e) => {
				if (e.key === "ArrowUp" || e.key === "ArrowRight") {
					e.preventDefault();
					onChange(clamp(value + 2, 0, 100));
				}
				if (e.key === "ArrowDown" || e.key === "ArrowLeft") {
					e.preventDefault();
					onChange(clamp(value - 2, 0, 100));
				}
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute inset-[3px] rounded-full bg-surface" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "absolute inset-0",
				style: { transform: `rotate(${angle}deg)` },
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute left-1/2 top-1.5 h-4 w-[2px] -translate-x-1/2 rounded-full bg-accent" })
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "text-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "font-display text-[11px] uppercase tracking-[0.14em] text-muted",
				children: label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "font-mono text-xs tabular-nums text-fg",
				children: Math.round(value)
			})]
		})]
	});
}
//#endregion
export { AmpKnob as t };
