import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { i as Search, o as Plus, r as Star } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { f as cn, h as useSession, i as Button, m as useLibrary, n as AMP_TYPES, o as CHANNEL_LABEL, r as AppShell, t as AMP_LABEL } from "./app-shell-BntSRKpV.mjs";
import { t as Input } from "./input-CM_DLr3M.mjs";
import { t as FxChainPips } from "./fx-chain-BSglswkC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Cfll9mem.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ToneCard({ tone, onSend, onFav, sending }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
		className: "rounded-lg bg-surface p-3 shadow-[0_0_0_1px_rgb(255_255_255/0.08)]",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-start gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/tone/$id",
				params: { id: tone.id },
				className: "min-w-0 flex-1 rounded-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-display text-[11px] uppercase tracking-[0.16em] text-muted",
							children: [
								AMP_LABEL[tone.ampType],
								" · V",
								tone.variation
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-[11px] text-subtle",
							children: CHANNEL_LABEL[tone.channel]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mt-1 truncate text-base font-medium text-fg",
						children: tone.name
					}),
					tone.song ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-0.5 truncate text-sm text-muted",
						children: tone.song
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2.5",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FxChainPips, { fx: tone.fx })
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex shrink-0 flex-col items-end gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": tone.favorite ? "Remove favorite" : "Favorite",
					onClick: onFav,
					className: cn("relative flex size-11 items-center justify-center rounded-sm text-muted transition-colors duration-150", tone.favorite && "text-fg"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: cn("size-4", tone.favorite && "fill-current") })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: "secondary",
					onClick: onSend,
					disabled: sending,
					children: sending ? "Sending" : "Send"
				})]
			})]
		})
	});
}
function LibraryPage() {
	const tones = useLibrary((s) => s.tones);
	const toggleFavorite = useLibrary((s) => s.toggleFavorite);
	const query = useSession((s) => s.query);
	const setQuery = useSession((s) => s.setQuery);
	const ampFilter = useSession((s) => s.ampFilter);
	const setAmpFilter = useSession((s) => s.setAmpFilter);
	const onlyFavs = useSession((s) => s.onlyFavs);
	const setOnlyFavs = useSession((s) => s.setOnlyFavs);
	const sendTone = useSession((s) => s.sendTone);
	const transport = useSession((s) => s.transport);
	const [sendingId, setSendingId] = (0, import_react.useState)(null);
	const filtered = (0, import_react.useMemo)(() => {
		const q = query.trim().toLowerCase();
		return tones.filter((tone) => {
			if (onlyFavs && !tone.favorite) return false;
			if (ampFilter !== "all" && tone.ampType !== ampFilter) return false;
			if (!q) return true;
			return `${tone.name} ${tone.song} ${tone.notes} ${tone.tags.join(" ")}`.toLowerCase().includes(q);
		});
	}, [
		tones,
		query,
		ampFilter,
		onlyFavs
	]);
	async function send(id) {
		const tone = tones.find((t) => t.id === id);
		if (!tone) return;
		setSendingId(id);
		try {
			await sendTone(tone);
			const dest = tone.channel === 0 ? "Panel" : `CH${tone.channel}`;
			toast.success(transport === "simulator" ? `${tone.name} → ${dest} on the demo amp` : `${tone.name} recalled ${dest}`);
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Send failed");
		} finally {
			setSendingId(null);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-subtle" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				value: query,
				onChange: (e) => setQuery(e.target.value),
				placeholder: "Search tones, songs, tags",
				className: "pl-10",
				"aria-label": "Search tones"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3 flex gap-1.5 overflow-x-auto pb-1",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
					active: ampFilter === "all" && !onlyFavs,
					onClick: () => {
						setAmpFilter("all");
						setOnlyFavs(false);
					},
					children: "All"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FilterChip, {
					active: onlyFavs,
					onClick: () => setOnlyFavs(!onlyFavs),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: cn("size-3", onlyFavs && "fill-current") }), "Favs"]
				}),
				AMP_TYPES.map((type) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
					active: ampFilter === type,
					onClick: () => setAmpFilter(ampFilter === type ? "all" : type),
					children: AMP_LABEL[type]
				}, type))
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 flex items-baseline justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					filtered.length,
					" tone",
					filtered.length === 1 ? "" : "s"
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/tone/$id",
				params: { id: "new" },
				className: "inline-flex min-h-11 items-center gap-1.5 text-sm font-medium text-fg",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "New tone"]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "stagger-in mt-3 grid gap-2.5",
			children: [filtered.map((tone) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToneCard, {
				tone,
				sending: sendingId === tone.id,
				onFav: () => toggleFavorite(tone.id),
				onSend: () => void send(tone.id)
			}, tone.id)), filtered.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-lg bg-surface px-4 py-10 text-center shadow-[0_0_0_1px_rgb(255_255_255/0.08)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-medium",
					children: "No tones match"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "Clear filters or add a new recipe."
				})]
			}) : null]
		})
	] });
}
function FilterChip({ active, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: cn("inline-flex h-9 shrink-0 items-center gap-1.5 rounded-full px-3 text-sm transition-colors duration-150", active ? "bg-accent text-accent-fg" : "bg-raised text-muted"),
		children
	});
}
//#endregion
export { LibraryPage as component };
