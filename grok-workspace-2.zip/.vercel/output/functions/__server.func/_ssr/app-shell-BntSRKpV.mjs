import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as Link, p as useRouterState } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as Radio, c as Library, f as Cable, l as Ellipsis, m as AudioLines, p as Bluetooth, s as ListMusic, t as Usb } from "../_libs/lucide-react.mjs";
import { l as Slot } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as Drawer } from "../_libs/vaul.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/app-shell-BntSRKpV.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function uid(prefix = "id") {
	return `${prefix}_${Math.random().toString(36).slice(2, 8)}${Date.now().toString(36).slice(-4)}`;
}
function clamp(n, min, max) {
	return Math.min(max, Math.max(min, n));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap font-medium transition-[opacity,transform,background-color,box-shadow,color] duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/50 disabled:pointer-events-none disabled:opacity-40 active:not-disabled:scale-[0.96] [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			primary: "bg-accent text-accent-fg shadow-[0_0_0_1px_rgb(255_255_255/0.06)] hover:opacity-90",
			secondary: "bg-raised text-fg shadow-[0_0_0_1px_rgb(255_255_255/0.08)] hover:bg-raised/80",
			ghost: "bg-transparent text-fg hover:bg-raised",
			danger: "bg-led text-fg hover:opacity-90",
			led: "bg-led/15 text-fg shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-led)_45%,transparent)] hover:bg-led/25"
		},
		size: {
			sm: "h-9 rounded-sm px-3 text-sm",
			md: "h-11 rounded-md px-4 text-sm",
			lg: "h-12 rounded-md px-5 text-base",
			icon: "size-11 rounded-md",
			pill: "h-9 rounded-full px-3.5 text-sm"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "md"
	}
});
function Button({ className, variant, size, asChild, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
function Drawer$1({ open, onOpenChange, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Drawer.Root, {
		open,
		onOpenChange,
		shouldScaleBackground: false,
		children
	});
}
function DrawerContent({ className, children, title }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Drawer.Portal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Drawer.Overlay, { className: "fixed inset-0 z-50 bg-bg/70" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Drawer.Content, {
		className: cn("fixed inset-x-0 bottom-0 z-50 mx-auto flex max-h-[92dvh] w-full max-w-lg flex-col rounded-t-xl bg-surface outline-none", "shadow-[0_0_0_1px_rgb(255_255_255/0.08)]", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto mt-3 h-1 w-10 rounded-full bg-border" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Drawer.Title, {
				className: "sr-only",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-y-auto px-5 pb-[max(1.5rem,env(safe-area-inset-bottom))] pt-4",
				children
			})
		]
	})] });
}
/** Roland/BOSS Katana Gen 3 SysEx helpers (community-confirmed). */
var GEN3_DT1 = [
	240,
	65,
	16,
	1,
	5,
	7,
	18
];
function toHex(bytes) {
	return Array.from(bytes).map((b) => b.toString(16).padStart(2, "0")).join(" ").toUpperCase();
}
/** Roland checksum: 128 − (sum of address+data modulo 128). */
function rolandChecksum(bytes) {
	return 128 - bytes.reduce((a, b) => a + (b & 127), 0) % 128 & 127;
}
function dt1(address, data) {
	const payload = [...address, ...data];
	return [
		...GEN3_DT1,
		...payload,
		rolandChecksum(payload),
		247
	];
}
/** Put the amp in editor (verbose) mode so it accepts patch recalls. */
function editorModeOn() {
	return dt1([
		127,
		0,
		0,
		1
	], [1]);
}
/**
* Recall Panel (0) or channel memory 1–8.
* Confirmed Gen 3: F0 41 10 01 05 07 12 7F 00 01 00 00 nn cs F7
*/
function selectPatch(channel) {
	return dt1([
		127,
		0,
		1,
		0
	], [Math.max(0, Math.min(8, channel | 0))]);
}
function programChange(program, midiChannel = 0) {
	const p = Math.max(0, Math.min(127, program | 0));
	return [192 | midiChannel & 15, p];
}
/** BLE-MIDI wraps each MIDI message with a 13-bit millisecond timestamp. */
function encodeBleMidi(message) {
	const t = Date.now() % 8192;
	const header = 128 | t >> 7 & 63;
	const timestamp = 128 | t & 127;
	return new Uint8Array([
		header,
		timestamp,
		...message
	]);
}
var BLE_MIDI_SERVICE = "03b80e5a-ede8-4b33-a751-6ce34ec4c700";
var BLE_MIDI_CHAR = "7772e5db-3868-4112-a1a9-f2669d106bf3";
function midiEvent(dir, label, bytes) {
	return {
		id: uid("midi"),
		at: Date.now(),
		dir,
		label,
		hex: toHex(bytes)
	};
}
function bluetoothSupported() {
	return typeof navigator !== "undefined" && "bluetooth" in navigator;
}
function webMidiSupported() {
	return typeof navigator !== "undefined" && "requestMIDIAccess" in navigator;
}
var KatanaLink = class {
	transport = "simulator";
	deviceName = "Katana 50 Gen 3 (Demo)";
	bleDevice = null;
	bleChar = null;
	midiOut = null;
	midiAccess = null;
	log;
	onDropped;
	constructor(log, onDropped) {
		this.log = log;
		this.onDropped = onDropped;
	}
	async sendBytes(bytes, label) {
		this.log(midiEvent("out", label, bytes));
		if (this.transport === "simulator") return;
		if (this.transport === "webmidi" && this.midiOut) {
			this.midiOut.send(bytes);
			return;
		}
		if (this.transport === "bluetooth" && this.bleChar) {
			const packet = encodeBleMidi(bytes);
			const buffer = packet.buffer.slice(packet.byteOffset, packet.byteOffset + packet.byteLength);
			try {
				if (this.bleChar.writeValueWithoutResponse) await this.bleChar.writeValueWithoutResponse(buffer);
				else await this.bleChar.writeValue(buffer);
			} catch (err) {
				throw new Error(err instanceof Error ? err.message : "Bluetooth write failed");
			}
		}
	}
	async recallChannel(channel) {
		await this.sendBytes(editorModeOn(), "Editor mode");
		await this.sendBytes(selectPatch(channel), `Recall ${channel === 0 ? "Panel" : `CH${channel}`}`);
		await this.sendBytes(programChange(channel), `Program change ${channel}`);
	}
	useSimulator() {
		this.disconnectHardware();
		this.transport = "simulator";
		this.deviceName = "Katana 50 Gen 3 (Demo)";
	}
	async connectBluetooth() {
		if (!bluetoothSupported()) throw new Error("Web Bluetooth is not available. Use Chrome on Android.");
		const device = await navigator.bluetooth.requestDevice({
			filters: [
				{ namePrefix: "KATANA" },
				{ namePrefix: "Katana" },
				{ namePrefix: "BT-DUAL" },
				{ services: [BLE_MIDI_SERVICE] }
			],
			optionalServices: [BLE_MIDI_SERVICE]
		});
		const characteristic = await (await (await device.gatt.connect()).getPrimaryService(BLE_MIDI_SERVICE)).getCharacteristic(BLE_MIDI_CHAR);
		try {
			await characteristic.startNotifications();
		} catch {}
		this.disconnectHardware();
		this.bleDevice = device;
		this.bleChar = characteristic;
		this.transport = "bluetooth";
		this.deviceName = device.name?.trim() || "KATANA 3 MIDI";
		device.addEventListener("gattserverdisconnected", () => {
			if (this.bleDevice === device) {
				this.transport = "simulator";
				this.deviceName = "Katana 50 Gen 3 (Demo)";
				this.bleDevice = null;
				this.bleChar = null;
				this.onDropped();
			}
		});
		await this.sendBytes(editorModeOn(), "Editor mode");
		return this.deviceName;
	}
	async connectBluetoothAny() {
		if (!bluetoothSupported()) throw new Error("Web Bluetooth is not available. Use Chrome on Android.");
		const device = await navigator.bluetooth.requestDevice({
			acceptAllDevices: true,
			optionalServices: [BLE_MIDI_SERVICE]
		});
		const characteristic = await (await (await device.gatt.connect()).getPrimaryService(BLE_MIDI_SERVICE)).getCharacteristic(BLE_MIDI_CHAR);
		try {
			await characteristic.startNotifications();
		} catch {}
		this.disconnectHardware();
		this.bleDevice = device;
		this.bleChar = characteristic;
		this.transport = "bluetooth";
		this.deviceName = device.name?.trim() || "BLE MIDI";
		device.addEventListener("gattserverdisconnected", () => {
			if (this.bleDevice === device) {
				this.transport = "simulator";
				this.deviceName = "Katana 50 Gen 3 (Demo)";
				this.bleDevice = null;
				this.bleChar = null;
				this.onDropped();
			}
		});
		await this.sendBytes(editorModeOn(), "Editor mode");
		return this.deviceName;
	}
	async connectWebMidi() {
		if (!webMidiSupported()) throw new Error("Web MIDI is not available in this browser.");
		const access = await navigator.requestMIDIAccess({ sysex: true });
		this.midiAccess = access;
		const outputs = [...access.outputs.values()];
		const preferred = outputs.find((o) => /katana/i.test(o.name ?? "")) ?? outputs.find((o) => /boss|roland/i.test(o.name ?? "")) ?? outputs[0];
		if (!preferred) throw new Error("No MIDI outputs found. Plug in USB or pair KATANA 3 MIDI first.");
		this.disconnectHardware();
		this.midiOut = preferred;
		this.transport = "webmidi";
		this.deviceName = preferred.name || "MIDI output";
		await this.sendBytes(editorModeOn(), "Editor mode");
		return this.deviceName;
	}
	listWebMidiOutputs() {
		if (!this.midiAccess) return [];
		return [...this.midiAccess.outputs.values()].map((o) => o.name || "MIDI");
	}
	disconnectHardware() {
		try {
			this.bleDevice?.gatt?.disconnect();
		} catch {}
		this.bleDevice = null;
		this.bleChar = null;
		this.midiOut = null;
	}
	disconnect() {
		this.disconnectHardware();
		this.useSimulator();
	}
};
var t = Date.now();
function tone(partial) {
	return {
		...partial,
		createdAt: t,
		updatedAt: t
	};
}
var FACTORY_TONES = [
	tone({
		id: "factory-glass-house",
		name: "Glass House",
		song: "Open chords, chorus shimmer",
		notes: "Keep the guitar volume at 7. Chorus before delay, hall sits behind the part.",
		favorite: true,
		tags: [
			"studio",
			"ambient",
			"rhythm"
		],
		channel: 1,
		ampType: "clean",
		variation: 1,
		knobs: {
			gain: 22,
			volume: 62,
			bass: 48,
			middle: 44,
			treble: 62,
			presence: 55,
			contour: 42,
			master: 38
		},
		fx: {
			booster: {
				on: false,
				type: "Clean Boost"
			},
			mod: {
				on: true,
				type: "Chorus"
			},
			fx: {
				on: false,
				type: "Compressor"
			},
			delay: {
				on: true,
				type: "Digital",
				timeMs: 420
			},
			reverb: {
				on: true,
				type: "Hall"
			}
		}
	}),
	tone({
		id: "factory-nashville-sparkle",
		name: "Nashville Sparkle",
		song: "Tele rhythm, session sheen",
		notes: "Slap delay on the quarter. Roll the tone knob back a touch on the guitar.",
		favorite: true,
		tags: [
			"country",
			"gig",
			"rhythm"
		],
		channel: 2,
		ampType: "clean",
		variation: 2,
		knobs: {
			gain: 28,
			volume: 58,
			bass: 42,
			middle: 50,
			treble: 70,
			presence: 64,
			contour: 38,
			master: 40
		},
		fx: {
			booster: {
				on: true,
				type: "Treble Boost"
			},
			mod: {
				on: false,
				type: "Chorus"
			},
			fx: {
				on: true,
				type: "Compressor"
			},
			delay: {
				on: true,
				type: "Slap",
				timeMs: 145
			},
			reverb: {
				on: true,
				type: "Room"
			}
		}
	}),
	tone({
		id: "factory-jazz-club",
		name: "Jazz Club",
		song: "Hollowbody ballad",
		notes: "Dark and round. Neck pickup, guitar tone at 4.",
		favorite: false,
		tags: ["studio", "practice"],
		channel: 3,
		ampType: "clean",
		variation: 1,
		knobs: {
			gain: 18,
			volume: 54,
			bass: 62,
			middle: 58,
			treble: 36,
			presence: 28,
			contour: 48,
			master: 36
		},
		fx: {
			booster: {
				on: false,
				type: "Clean Boost"
			},
			mod: {
				on: false,
				type: "Chorus"
			},
			fx: {
				on: true,
				type: "Compressor"
			},
			delay: {
				on: false,
				type: "Analog",
				timeMs: 300
			},
			reverb: {
				on: true,
				type: "Spring"
			}
		}
	}),
	tone({
		id: "factory-funk-tick",
		name: "Funk Tick",
		song: "16th-note chicken pickin'",
		notes: "Compressor always on. Mute the low E unless the riff needs it.",
		favorite: false,
		tags: [
			"funk",
			"gig",
			"rhythm"
		],
		channel: 4,
		ampType: "clean",
		variation: 2,
		knobs: {
			gain: 24,
			volume: 60,
			bass: 38,
			middle: 62,
			treble: 68,
			presence: 58,
			contour: 34,
			master: 40
		},
		fx: {
			booster: {
				on: false,
				type: "Clean Boost"
			},
			mod: {
				on: false,
				type: "Phaser"
			},
			fx: {
				on: true,
				type: "Compressor"
			},
			delay: {
				on: false,
				type: "Slap",
				timeMs: 90
			},
			reverb: {
				on: true,
				type: "Ambience"
			}
		}
	}),
	tone({
		id: "factory-bluesbreaker",
		name: "Bluesbreaker",
		song: "Slow blues, Les Paul",
		notes: "Kick the boost for the solo. Bridge pickup, guitar volume swells.",
		favorite: true,
		tags: [
			"blues",
			"gig",
			"lead"
		],
		channel: 5,
		ampType: "crunch",
		variation: 1,
		knobs: {
			gain: 48,
			volume: 56,
			bass: 52,
			middle: 60,
			treble: 54,
			presence: 48,
			contour: 46,
			master: 42
		},
		fx: {
			booster: {
				on: true,
				type: "Blues Drive"
			},
			mod: {
				on: false,
				type: "Chorus"
			},
			fx: {
				on: false,
				type: "T.Wah"
			},
			delay: {
				on: true,
				type: "Analog",
				timeMs: 380
			},
			reverb: {
				on: true,
				type: "Room"
			}
		}
	}),
	tone({
		id: "factory-ac-smash",
		name: "AC Smash",
		song: "Open-G rock riff",
		notes: "Variation 2 tightens the low end. Don't stack delay on the riff.",
		favorite: false,
		tags: [
			"rock",
			"gig",
			"rhythm"
		],
		channel: 6,
		ampType: "crunch",
		variation: 2,
		knobs: {
			gain: 58,
			volume: 54,
			bass: 46,
			middle: 64,
			treble: 58,
			presence: 52,
			contour: 40,
			master: 44
		},
		fx: {
			booster: {
				on: false,
				type: "Overdrive"
			},
			mod: {
				on: false,
				type: "Tremolo"
			},
			fx: {
				on: false,
				type: "Compressor"
			},
			delay: {
				on: false,
				type: "Tape Echo",
				timeMs: 280
			},
			reverb: {
				on: true,
				type: "Plate"
			}
		}
	}),
	tone({
		id: "factory-texas-flood",
		name: "Texas Flood",
		song: "SRV-style shuffle",
		notes: "Mid boost into crunch. Strat in position 4, guitar volume at 8.",
		favorite: true,
		tags: [
			"blues",
			"studio",
			"lead"
		],
		channel: 7,
		ampType: "crunch",
		variation: 1,
		knobs: {
			gain: 54,
			volume: 58,
			bass: 50,
			middle: 68,
			treble: 50,
			presence: 44,
			contour: 52,
			master: 42
		},
		fx: {
			booster: {
				on: true,
				type: "Mid Boost"
			},
			mod: {
				on: false,
				type: "Uni-V"
			},
			fx: {
				on: false,
				type: "Octave"
			},
			delay: {
				on: true,
				type: "Tape Echo",
				timeMs: 360
			},
			reverb: {
				on: true,
				type: "Spring"
			}
		}
	}),
	tone({
		id: "factory-punk-buzz",
		name: "Punk Buzz",
		song: "Four chords, no solos",
		notes: "Bright, mid-forward, almost no reverb. Downstrokes only.",
		favorite: false,
		tags: [
			"rock",
			"gig",
			"rhythm"
		],
		channel: 8,
		ampType: "crunch",
		variation: 2,
		knobs: {
			gain: 64,
			volume: 60,
			bass: 40,
			middle: 70,
			treble: 66,
			presence: 60,
			contour: 30,
			master: 46
		},
		fx: {
			booster: {
				on: true,
				type: "Distortion"
			},
			mod: {
				on: false,
				type: "Flanger"
			},
			fx: {
				on: false,
				type: "Compressor"
			},
			delay: {
				on: false,
				type: "Digital",
				timeMs: 200
			},
			reverb: {
				on: false,
				type: "Room"
			}
		}
	}),
	tone({
		id: "factory-arena-solo",
		name: "Arena Solo",
		song: "Big chorus, last eight bars",
		notes: "Delay dotted-eighth at 120 BPM. Boost on, reverb long.",
		favorite: true,
		tags: [
			"rock",
			"gig",
			"lead"
		],
		channel: 1,
		ampType: "lead",
		variation: 1,
		knobs: {
			gain: 68,
			volume: 62,
			bass: 48,
			middle: 58,
			treble: 60,
			presence: 62,
			contour: 44,
			master: 44
		},
		fx: {
			booster: {
				on: true,
				type: "Clean Boost"
			},
			mod: {
				on: false,
				type: "Chorus"
			},
			fx: {
				on: false,
				type: "Pitch Shifter"
			},
			delay: {
				on: true,
				type: "Digital",
				timeMs: 375
			},
			reverb: {
				on: true,
				type: "Hall"
			}
		}
	}),
	tone({
		id: "factory-fusion-sing",
		name: "Fusion Sing",
		song: "Neck-pickup legato",
		notes: "Smooth gain, chorus barely on. Roll contour down to fatten.",
		favorite: false,
		tags: ["studio", "lead"],
		channel: 2,
		ampType: "lead",
		variation: 2,
		knobs: {
			gain: 60,
			volume: 55,
			bass: 56,
			middle: 52,
			treble: 48,
			presence: 50,
			contour: 58,
			master: 40
		},
		fx: {
			booster: {
				on: false,
				type: "Overdrive"
			},
			mod: {
				on: true,
				type: "Chorus"
			},
			fx: {
				on: true,
				type: "Compressor"
			},
			delay: {
				on: true,
				type: "Analog",
				timeMs: 440
			},
			reverb: {
				on: true,
				type: "Plate"
			}
		}
	}),
	tone({
		id: "factory-classic-800",
		name: "Classic 800",
		song: "British stack rhythm",
		notes: "Palm mute the 16ths. Variation 2 for tighter chugs on the chorus.",
		favorite: false,
		tags: [
			"rock",
			"metal",
			"rhythm"
		],
		channel: 3,
		ampType: "lead",
		variation: 1,
		knobs: {
			gain: 72,
			volume: 52,
			bass: 44,
			middle: 66,
			treble: 58,
			presence: 54,
			contour: 36,
			master: 44
		},
		fx: {
			booster: {
				on: false,
				type: "Metal DS"
			},
			mod: {
				on: false,
				type: "Phaser"
			},
			fx: {
				on: false,
				type: "Compressor"
			},
			delay: {
				on: false,
				type: "Digital",
				timeMs: 250
			},
			reverb: {
				on: true,
				type: "Room"
			}
		}
	}),
	tone({
		id: "factory-brownface",
		name: "Brownface Stack",
		song: "High-gain verse",
		notes: "Katana Brown, variation 1. Cut bass if it blooms on the 4x12 sim.",
		favorite: true,
		tags: [
			"metal",
			"gig",
			"rhythm"
		],
		channel: 4,
		ampType: "brown",
		variation: 1,
		knobs: {
			gain: 74,
			volume: 50,
			bass: 42,
			middle: 62,
			treble: 56,
			presence: 58,
			contour: 34,
			master: 42
		},
		fx: {
			booster: {
				on: false,
				type: "Fat DS"
			},
			mod: {
				on: false,
				type: "Flanger"
			},
			fx: {
				on: false,
				type: "Guitar Sim"
			},
			delay: {
				on: false,
				type: "Digital",
				timeMs: 280
			},
			reverb: {
				on: true,
				type: "Ambience"
			}
		}
	}),
	tone({
		id: "factory-modern-chug",
		name: "Modern Chug",
		song: "Drop-C breakdown",
		notes: "Contour down, bass modest. Noise is the guitar — mute hard.",
		favorite: false,
		tags: [
			"metal",
			"gig",
			"rhythm"
		],
		channel: 5,
		ampType: "brown",
		variation: 2,
		knobs: {
			gain: 82,
			volume: 48,
			bass: 36,
			middle: 70,
			treble: 52,
			presence: 50,
			contour: 22,
			master: 40
		},
		fx: {
			booster: {
				on: true,
				type: "Metal DS"
			},
			mod: {
				on: false,
				type: "Slicer"
			},
			fx: {
				on: false,
				type: "Octave"
			},
			delay: {
				on: false,
				type: "Digital",
				timeMs: 180
			},
			reverb: {
				on: false,
				type: "Room"
			}
		}
	}),
	tone({
		id: "factory-vintage-plexi",
		name: "Vintage Plexi",
		song: "Open chords, 1970",
		notes: "Don't dime gain. Let the strings bloom, then stomp boost for the break.",
		favorite: false,
		tags: [
			"rock",
			"studio",
			"rhythm"
		],
		channel: 6,
		ampType: "brown",
		variation: 1,
		knobs: {
			gain: 58,
			volume: 56,
			bass: 54,
			middle: 60,
			treble: 50,
			presence: 46,
			contour: 50,
			master: 42
		},
		fx: {
			booster: {
				on: false,
				type: "Blues Drive"
			},
			mod: {
				on: false,
				type: "Tremolo"
			},
			fx: {
				on: false,
				type: "Compressor"
			},
			delay: {
				on: true,
				type: "Tape Echo",
				timeMs: 320
			},
			reverb: {
				on: true,
				type: "Spring"
			}
		}
	}),
	tone({
		id: "factory-campfire",
		name: "Campfire",
		song: "Flatpick acoustic",
		notes: "Acoustic type, variation 1. Body from contour, not bass.",
		favorite: true,
		tags: [
			"acoustic",
			"practice",
			"rhythm"
		],
		channel: 7,
		ampType: "acoustic",
		variation: 1,
		knobs: {
			gain: 20,
			volume: 58,
			bass: 44,
			middle: 52,
			treble: 60,
			presence: 48,
			contour: 62,
			master: 38
		},
		fx: {
			booster: {
				on: false,
				type: "Clean Boost"
			},
			mod: {
				on: false,
				type: "Chorus"
			},
			fx: {
				on: true,
				type: "Compressor"
			},
			delay: {
				on: false,
				type: "Digital",
				timeMs: 240
			},
			reverb: {
				on: true,
				type: "Hall"
			}
		}
	}),
	tone({
		id: "factory-piezo-shine",
		name: "Piezo Shine",
		song: "Fingerstyle intro",
		notes: "Tame the piezo quack with contour. Soft compressor, long hall.",
		favorite: false,
		tags: ["acoustic", "studio"],
		channel: 8,
		ampType: "acoustic",
		variation: 2,
		knobs: {
			gain: 16,
			volume: 55,
			bass: 40,
			middle: 48,
			treble: 64,
			presence: 42,
			contour: 70,
			master: 36
		},
		fx: {
			booster: {
				on: false,
				type: "Clean Boost"
			},
			mod: {
				on: true,
				type: "Chorus"
			},
			fx: {
				on: true,
				type: "Compressor"
			},
			delay: {
				on: true,
				type: "Digital",
				timeMs: 480
			},
			reverb: {
				on: true,
				type: "Cathedral"
			}
		}
	}),
	tone({
		id: "factory-ambient-wash",
		name: "Ambient Wash",
		song: "Volume-swell pads",
		notes: "Clean, both delays-worth of hall. Play behind the beat.",
		favorite: true,
		tags: [
			"ambient",
			"studio",
			"lead"
		],
		channel: 3,
		ampType: "clean",
		variation: 1,
		knobs: {
			gain: 14,
			volume: 64,
			bass: 50,
			middle: 42,
			treble: 58,
			presence: 52,
			contour: 54,
			master: 38
		},
		fx: {
			booster: {
				on: false,
				type: "Clean Boost"
			},
			mod: {
				on: true,
				type: "Chorus"
			},
			fx: {
				on: true,
				type: "Slow Gear"
			},
			delay: {
				on: true,
				type: "Reverse",
				timeMs: 620
			},
			reverb: {
				on: true,
				type: "Modulate"
			}
		}
	}),
	tone({
		id: "factory-surf-splash",
		name: "Surf Splash",
		song: "Spring-and-tremolo instrumental",
		notes: "Tremolo speed around 5. Spring reverb as loud as the dry.",
		favorite: false,
		tags: ["gig", "rhythm"],
		channel: 4,
		ampType: "clean",
		variation: 2,
		knobs: {
			gain: 30,
			volume: 60,
			bass: 46,
			middle: 48,
			treble: 72,
			presence: 66,
			contour: 32,
			master: 42
		},
		fx: {
			booster: {
				on: false,
				type: "Treble Boost"
			},
			mod: {
				on: true,
				type: "Tremolo"
			},
			fx: {
				on: false,
				type: "Compressor"
			},
			delay: {
				on: false,
				type: "Slap",
				timeMs: 110
			},
			reverb: {
				on: true,
				type: "Spring"
			}
		}
	}),
	tone({
		id: "factory-drop-d",
		name: "Drop-D Weight",
		song: "Sabbath-leaning riff",
		notes: "Brown, variation 2. Leave reverb off so the chug stays square.",
		favorite: false,
		tags: [
			"rock",
			"metal",
			"rhythm"
		],
		channel: 5,
		ampType: "brown",
		variation: 2,
		knobs: {
			gain: 66,
			volume: 52,
			bass: 58,
			middle: 54,
			treble: 44,
			presence: 40,
			contour: 28,
			master: 42
		},
		fx: {
			booster: {
				on: false,
				type: "Fat DS"
			},
			mod: {
				on: false,
				type: "Uni-V"
			},
			fx: {
				on: false,
				type: "Octave"
			},
			delay: {
				on: false,
				type: "Analog",
				timeMs: 220
			},
			reverb: {
				on: false,
				type: "Room"
			}
		}
	}),
	tone({
		id: "factory-bedroom-lead",
		name: "Bedroom Lead",
		song: "Quiet apartment solo",
		notes: "Master low, gain high. Delay keeps notes singing at whisper volume.",
		favorite: true,
		tags: ["practice", "lead"],
		channel: 6,
		ampType: "lead",
		variation: 2,
		knobs: {
			gain: 70,
			volume: 58,
			bass: 50,
			middle: 56,
			treble: 54,
			presence: 58,
			contour: 46,
			master: 22
		},
		fx: {
			booster: {
				on: true,
				type: "Clean Boost"
			},
			mod: {
				on: false,
				type: "Vibrato"
			},
			fx: {
				on: false,
				type: "Pitch Shifter"
			},
			delay: {
				on: true,
				type: "Modulation",
				timeMs: 410
			},
			reverb: {
				on: true,
				type: "Hall"
			}
		}
	})
];
var FACTORY_SETLISTS = [{
	id: "set-friday-club",
	name: "Friday Club",
	venue: "The Basement, 9pm",
	toneIds: [
		"factory-nashville-sparkle",
		"factory-bluesbreaker",
		"factory-ac-smash",
		"factory-texas-flood",
		"factory-arena-solo",
		"factory-punk-buzz",
		"factory-brownface",
		"factory-glass-house"
	],
	createdAt: t
}, {
	id: "set-studio-night",
	name: "Studio Night",
	venue: "Tracking room B",
	toneIds: [
		"factory-jazz-club",
		"factory-piezo-shine",
		"factory-ambient-wash",
		"factory-fusion-sing",
		"factory-vintage-plexi"
	],
	createdAt: t
}];
var AMP_TYPES = [
	"clean",
	"crunch",
	"lead",
	"brown",
	"acoustic"
];
var CHANNELS = [
	0,
	1,
	2,
	3,
	4,
	5,
	6,
	7,
	8
];
var AMP_LABEL = {
	clean: "Clean",
	crunch: "Crunch",
	lead: "Lead",
	brown: "Brown",
	acoustic: "Acoustic"
};
var CHANNEL_LABEL = {
	0: "Panel",
	1: "CH1",
	2: "CH2",
	3: "CH3",
	4: "CH4",
	5: "CH5",
	6: "CH6",
	7: "CH7",
	8: "CH8"
};
var KNOB_META = [
	{
		key: "gain",
		label: "Gain"
	},
	{
		key: "volume",
		label: "Volume"
	},
	{
		key: "bass",
		label: "Bass"
	},
	{
		key: "middle",
		label: "Middle"
	},
	{
		key: "treble",
		label: "Treble"
	},
	{
		key: "presence",
		label: "Presence"
	},
	{
		key: "contour",
		label: "Contour"
	},
	{
		key: "master",
		label: "Master"
	}
];
var FX_ORDER = [
	"booster",
	"mod",
	"fx",
	"delay",
	"reverb"
];
var FX_LABEL = {
	booster: "Boost",
	mod: "Mod",
	fx: "FX",
	delay: "Delay",
	reverb: "Rev"
};
function emptyKnobs() {
	return {
		gain: 50,
		volume: 50,
		bass: 50,
		middle: 50,
		treble: 50,
		presence: 50,
		contour: 50,
		master: 40
	};
}
function emptyFx() {
	return {
		booster: {
			on: false,
			type: "Clean Boost"
		},
		mod: {
			on: false,
			type: "Chorus"
		},
		fx: {
			on: false,
			type: "Compressor"
		},
		delay: {
			on: false,
			type: "Digital",
			timeMs: 380
		},
		reverb: {
			on: false,
			type: "Hall"
		}
	};
}
function blankTone(id) {
	const now = Date.now();
	return {
		id,
		name: "Untitled tone",
		song: "",
		notes: "",
		favorite: false,
		tags: [],
		channel: 1,
		ampType: "clean",
		variation: 1,
		knobs: emptyKnobs(),
		fx: emptyFx(),
		createdAt: now,
		updatedAt: now
	};
}
var useLibrary = create()(persist((set) => ({
	tones: FACTORY_TONES,
	setlists: FACTORY_SETLISTS,
	upsertTone: (tone) => set((s) => {
		const idx = s.tones.findIndex((t) => t.id === tone.id);
		const next = [...s.tones];
		const saved = {
			...tone,
			updatedAt: Date.now()
		};
		if (idx >= 0) next[idx] = saved;
		else next.unshift(saved);
		return { tones: next };
	}),
	deleteTone: (id) => set((s) => ({
		tones: s.tones.filter((t) => t.id !== id),
		setlists: s.setlists.map((sl) => ({
			...sl,
			toneIds: sl.toneIds.filter((tid) => tid !== id)
		}))
	})),
	toggleFavorite: (id) => set((s) => ({ tones: s.tones.map((t) => t.id === id ? {
		...t,
		favorite: !t.favorite,
		updatedAt: Date.now()
	} : t) })),
	addSetlist: (name, venue = "") => {
		const id = uid("set");
		set((s) => ({ setlists: [{
			id,
			name,
			venue,
			toneIds: [],
			createdAt: Date.now()
		}, ...s.setlists] }));
		return id;
	},
	updateSetlist: (id, patch) => set((s) => ({ setlists: s.setlists.map((sl) => sl.id === id ? {
		...sl,
		...patch
	} : sl) })),
	deleteSetlist: (id) => set((s) => ({ setlists: s.setlists.filter((sl) => sl.id !== id) })),
	resetFactory: () => set({
		tones: FACTORY_TONES,
		setlists: FACTORY_SETLISTS
	}),
	replaceAll: (tones, setlists) => set({
		tones,
		setlists
	})
}), {
	name: "katana-case-library",
	skipHydration: true
}));
var link = null;
function getLink() {
	if (!link) link = new KatanaLink((event) => useSession.setState((s) => ({ log: [event, ...s.log].slice(0, 40) })), () => useSession.setState({
		status: "connected",
		transport: "simulator",
		deviceName: "Katana 50 Gen 3 (Demo)",
		error: "Amp disconnected — back on the demo amp."
	}));
	return link;
}
var useSession = create()((set, get) => ({
	hydrated: false,
	setHydrated: () => set({ hydrated: true }),
	query: "",
	ampFilter: "all",
	onlyFavs: false,
	setQuery: (query) => set({ query }),
	setAmpFilter: (ampFilter) => set({ ampFilter }),
	setOnlyFavs: (onlyFavs) => set({ onlyFavs }),
	activeToneId: FACTORY_TONES[0]?.id ?? null,
	setActiveToneId: (activeToneId) => set({ activeToneId }),
	currentChannel: 1,
	setCurrentChannel: (currentChannel) => set({ currentChannel }),
	status: "connected",
	transport: "simulator",
	deviceName: "Katana 50 Gen 3 (Demo)",
	error: null,
	log: [],
	connectOpen: false,
	setConnectOpen: (connectOpen) => set({ connectOpen }),
	connectBluetooth: async (anyDevice = false) => {
		set({
			status: "connecting",
			error: null
		});
		try {
			const name = anyDevice ? await getLink().connectBluetoothAny() : await getLink().connectBluetooth();
			set({
				status: "connected",
				transport: getLink().transport,
				deviceName: name,
				error: null
			});
		} catch (err) {
			const msg = err instanceof Error ? err.message : "Could not connect";
			getLink().useSimulator();
			set({
				status: "connected",
				transport: "simulator",
				deviceName: "Katana 50 Gen 3 (Demo)",
				error: msg
			});
			throw err;
		}
	},
	connectWebMidi: async () => {
		set({
			status: "connecting",
			error: null
		});
		try {
			const name = await getLink().connectWebMidi();
			set({
				status: "connected",
				transport: getLink().transport,
				deviceName: name,
				error: null
			});
		} catch (err) {
			const msg = err instanceof Error ? err.message : "Could not connect";
			getLink().useSimulator();
			set({
				status: "connected",
				transport: "simulator",
				deviceName: "Katana 50 Gen 3 (Demo)",
				error: msg
			});
			throw err;
		}
	},
	useSimulator: () => {
		getLink().useSimulator();
		set({
			status: "connected",
			transport: "simulator",
			deviceName: "Katana 50 Gen 3 (Demo)",
			error: null
		});
	},
	disconnect: () => {
		getLink().disconnect();
		set({
			status: "connected",
			transport: "simulator",
			deviceName: "Katana 50 Gen 3 (Demo)",
			error: null
		});
	},
	recallChannel: async (ch) => {
		set({ currentChannel: ch });
		const tones = useLibrary.getState().tones;
		const mapped = tones.find((t) => t.id === get().activeToneId && t.channel === ch) ?? tones.find((t) => t.channel === ch);
		if (mapped) set({ activeToneId: mapped.id });
		await getLink().recallChannel(ch);
	},
	sendTone: async (tone) => {
		set({
			activeToneId: tone.id,
			currentChannel: tone.channel
		});
		await getLink().recallChannel(tone.channel);
	}
}));
function newToneDraft() {
	return blankTone(uid("tone"));
}
function ConnectSheet() {
	const open = useSession((s) => s.connectOpen);
	const setOpen = useSession((s) => s.setConnectOpen);
	const status = useSession((s) => s.status);
	const transport = useSession((s) => s.transport);
	const deviceName = useSession((s) => s.deviceName);
	const error = useSession((s) => s.error);
	const connecting = status === "connecting";
	const connectBluetooth = useSession((s) => s.connectBluetooth);
	const connectWebMidi = useSession((s) => s.connectWebMidi);
	const useSimulator = useSession((s) => s.useSimulator);
	async function run(fn, ok) {
		try {
			await fn();
			toast.success(ok);
			setOpen(false);
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not connect");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Drawer$1, {
		open,
		onOpenChange: setOpen,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DrawerContent, {
			title: "Connect amp",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-xs uppercase tracking-[0.22em] text-muted",
					children: "Connection"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-1 text-xl font-medium",
					children: "Talk to the Katana"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: "Hardware needs a BOSS BT-DUAL in the amp’s Bluetooth port and Chrome on Android. The demo amp always works in this preview."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 rounded-md bg-raised p-3 shadow-[0_0_0_1px_rgb(255_255_255/0.06)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: transport === "simulator" ? "led-pip" : "led-pip on" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium",
								children: deviceName
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-xs text-muted",
							children: [
								transport === "simulator" && "Demo amp — recalls stay in the app.",
								transport === "bluetooth" && "Bluetooth MIDI — recalling a channel hits the amp.",
								transport === "webmidi" && "USB / Web MIDI — SysEx goes to the output."
							]
						}),
						error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-xs text-led",
							children: error
						}) : null
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 grid gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "primary",
							disabled: connecting || !bluetoothSupported(),
							onClick: () => run(() => connectBluetooth(false), "Katana connected over Bluetooth"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bluetooth, {}), "Connect KATANA 3 MIDI"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "secondary",
							disabled: connecting || !bluetoothSupported(),
							onClick: () => run(() => connectBluetooth(true), "MIDI device connected"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radio, {}), "Scan any BLE MIDI device"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "secondary",
							disabled: connecting || !webMidiSupported(),
							onClick: () => run(() => connectWebMidi(), "MIDI output connected"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Usb, {}), "Connect USB MIDI"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "ghost",
							disabled: connecting,
							onClick: () => {
								useSimulator();
								toast.message("Using the demo amp");
								setOpen(false);
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cable, {}), "Stay on demo amp"]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
					className: "mt-6 space-y-2 text-sm text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "1. Fit the BT-DUAL. Power the amp. Blue LED should blink slowly." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "2. Enable Bluetooth on the phone. Do not pair “KATANA 3 MIDI” in system settings." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "3. Tap Connect above and choose KATANA 3 MIDI in the Chrome picker." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "4. Sending a tone recalls Panel or CH1–CH8 on the amp." })
					]
				})
			]
		})
	});
}
var NAV = [
	{
		to: "/",
		label: "Library",
		icon: Library,
		exact: true
	},
	{
		to: "/panel",
		label: "Panel",
		icon: AudioLines,
		exact: false
	},
	{
		to: "/setlists",
		label: "Setlists",
		icon: ListMusic,
		exact: false
	},
	{
		to: "/more",
		label: "More",
		icon: Ellipsis,
		exact: false
	}
];
function AppShell({ children }) {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const setHydrated = useSession((s) => s.setHydrated);
	const hydrated = useSession((s) => s.hydrated);
	const transport = useSession((s) => s.transport);
	const deviceName = useSession((s) => s.deviceName);
	const setConnectOpen = useSession((s) => s.setConnectOpen);
	(0, import_react.useEffect)(() => {
		useLibrary.persist.rehydrate();
		setHydrated();
	}, [setHydrated]);
	const live = transport !== "simulator";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "app-shell mx-auto flex max-w-lg flex-col bg-bg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-30 flex items-center gap-3 border-b border-border bg-bg/95 px-4 pb-3 pt-[max(0.75rem,env(safe-area-inset-top))] backdrop-blur-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-[11px] uppercase tracking-[0.28em] text-muted",
						children: "Katana Gen 3"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-xl uppercase tracking-[0.12em] text-fg",
						children: "Katana Case"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setConnectOpen(true),
					className: "flex min-h-11 max-w-[11rem] items-center gap-2 rounded-full bg-raised px-3 py-1.5 text-left shadow-[0_0_0_1px_rgb(255_255_255/0.08)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("led-pip shrink-0", live && "on") }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block truncate text-xs font-medium text-fg",
							children: live ? "Live" : "Demo"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block truncate text-[10px] text-muted",
							children: deviceName
						})]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex-1 px-4 pb-28 pt-4",
				children: hydrated ? children : children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "fixed inset-x-0 bottom-0 z-30 mx-auto max-w-lg border-t border-border bg-bg/95 pb-[max(0.4rem,env(safe-area-inset-bottom))] pt-1 backdrop-blur-sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "grid grid-cols-4",
					children: NAV.map((item) => {
						const active = item.exact ? pathname === item.to : pathname.startsWith(item.to);
						const Icon = item.icon;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: item.to,
							className: cn("flex min-h-12 flex-col items-center justify-center gap-0.5 text-[11px] font-medium", active ? "text-fg" : "text-muted"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
								className: "size-5",
								strokeWidth: active ? 2.2 : 1.8
							}), item.label]
						}) }, item.to);
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConnectSheet, {})
		]
	});
}
//#endregion
export { CHANNELS as a, FX_ORDER as c, clamp as d, cn as f, webMidiSupported as g, useSession as h, Button as i, KNOB_META as l, useLibrary as m, AMP_TYPES as n, CHANNEL_LABEL as o, newToneDraft as p, AppShell as r, FX_LABEL as s, AMP_LABEL as t, bluetoothSupported as u };
