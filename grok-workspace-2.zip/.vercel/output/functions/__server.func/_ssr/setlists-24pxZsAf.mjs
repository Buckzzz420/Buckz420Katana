import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { o as Plus } from "../_libs/lucide-react.mjs";
import { i as Button, m as useLibrary, r as AppShell } from "./app-shell-BntSRKpV.mjs";
import { t as Input } from "./input-CM_DLr3M.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/setlists-24pxZsAf.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function SetlistsPage() {
	const setlists = useLibrary((s) => s.setlists);
	const tones = useLibrary((s) => s.tones);
	const addSetlist = useLibrary((s) => s.addSetlist);
	const deleteSetlist = useLibrary((s) => s.deleteSetlist);
	const [name, setName] = (0, import_react.useState)("");
	function create() {
		const trimmed = name.trim() || "New setlist";
		addSetlist(trimmed);
		setName("");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex items-end justify-between gap-3",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-[11px] uppercase tracking-[0.22em] text-muted",
				children: "Gigs"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-xl font-medium",
				children: "Setlists"
			})] })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 flex gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				value: name,
				placeholder: "Setlist name",
				onChange: (e) => setName(e.target.value),
				onKeyDown: (e) => {
					if (e.key === "Enter") create();
				}
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "secondary",
				size: "icon",
				"aria-label": "Add setlist",
				onClick: create,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {})
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "stagger-in mt-4 grid gap-2.5",
			children: [setlists.map((sl) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
				className: "rounded-lg bg-surface p-4 shadow-[0_0_0_1px_rgb(255_255_255/0.08)]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/setlists/$id",
						params: { id: sl.id },
						className: "min-w-0 flex-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "truncate text-base font-medium",
								children: sl.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-0.5 text-sm text-muted",
								children: [
									sl.venue || "No venue",
									" · ",
									sl.toneIds.length,
									" tones"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 truncate text-xs text-subtle",
								children: sl.toneIds.map((id) => tones.find((t) => t.id === id)?.name).filter(Boolean).join(" · ") || "Empty"
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "min-h-11 text-sm text-muted",
						onClick: () => deleteSetlist(sl.id),
						children: "Remove"
					})]
				})
			}, sl.id)), setlists.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "py-10 text-center text-sm text-muted",
				children: "No setlists yet."
			}) : null]
		})
	] });
}
//#endregion
export { SetlistsPage as component };
