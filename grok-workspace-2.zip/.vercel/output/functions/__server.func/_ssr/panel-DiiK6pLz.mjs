import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as CHANNELS, f as cn, h as useSession, i as Button, l as KNOB_META, m as useLibrary, n as AMP_TYPES, o as CHANNEL_LABEL, r as AppShell, t as AMP_LABEL } from "./app-shell-BntSRKpV.mjs";
import { n as FxToggleRow } from "./fx-chain-BSglswkC.mjs";
import { t as AmpKnob } from "./amp-knob-No3XKkbx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/panel-DiiK6pLz.js
var import_jsx_runtime = require_jsx_runtime();
function ChannelStrip({ current, onSelect }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid grid-cols-9 gap-1",
		children: CHANNELS.map((ch) => {
			const on = current === ch;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => onSelect(ch),
				className: cn("flex min-h-12 flex-col items-center justify-center gap-1 rounded-sm transition-[background-color,box-shadow] duration-150 ease-out", on ? "bg-led/15 shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-led)_55%,transparent)]" : "bg-raised shadow-[0_0_0_1px_rgb(255_255_255/0.06)]"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("led-pip", on && "on") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-display text-[9px] uppercase tracking-[0.12em] text-fg",
					children: CHANNEL_LABEL[ch]
				})]
			}, ch);
		})
	});
}
function AmpPanel({ tone, channel, onChannel, onTone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-xl bg-surface p-4 shadow-[0_0_0_1px_rgb(255_255_255/0.08)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 flex items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-[11px] uppercase tracking-[0.22em] text-muted",
					children: "Front panel"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-0.5 text-lg font-medium",
					children: tone?.name ?? "No tone on this channel"
				})] }), tone ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "font-display text-xs uppercase tracking-[0.14em] text-muted",
					children: [
						AMP_LABEL[tone.ampType],
						" V",
						tone.variation
					]
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChannelStrip, {
				current: channel,
				onSelect: onChannel
			}),
			tone ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 grid grid-cols-5 gap-1.5",
					children: AMP_TYPES.map((type) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AmpTypeKey, {
						type,
						active: tone.ampType === type,
						onClick: () => onTone({ ampType: type })
					}, type))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 grid grid-cols-2 gap-1.5",
					children: [1, 2].map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => onTone({ variation: v }),
						className: cn("flex min-h-11 items-center justify-center gap-2 rounded-md text-sm transition-colors duration-150", tone.variation === v ? "bg-accent text-accent-fg" : "bg-raised text-muted shadow-[0_0_0_1px_rgb(255_255_255/0.06)]"),
						children: ["Variation ", v]
					}, v))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-5 flex gap-1 overflow-x-auto pb-1",
					children: KNOB_META.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AmpKnob, {
						label: k.label,
						value: tone.knobs[k.key],
						onChange: (value) => onTone({ knobs: {
							...tone.knobs,
							[k.key]: value
						} })
					}, k.key))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-5",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FxToggleRow, {
						fx: tone.fx,
						onToggle: (key) => onTone({ fx: {
							...tone.fx,
							[key]: {
								...tone.fx[key],
								on: !tone.fx[key].on
							}
						} })
					})
				})
			] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 text-sm text-muted",
				children: "Map a library tone to this channel, then send it. The hardware recall hits Panel or CH1–CH8."
			})
		]
	});
}
function AmpTypeKey({ type, active, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: cn("flex min-h-12 flex-col items-center justify-center gap-1 rounded-md px-1 transition-[background-color] duration-150", active ? "bg-led/15" : "bg-raised shadow-[0_0_0_1px_rgb(255_255_255/0.06)]"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("led-pip", active && "on") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-display text-[9px] uppercase tracking-[0.12em]",
			children: AMP_LABEL[type]
		})]
	});
}
function PanelPage() {
	const tones = useLibrary((s) => s.tones);
	const upsertTone = useLibrary((s) => s.upsertTone);
	const currentChannel = useSession((s) => s.currentChannel);
	const recallChannel = useSession((s) => s.recallChannel);
	const activeToneId = useSession((s) => s.activeToneId);
	const sendTone = useSession((s) => s.sendTone);
	const transport = useSession((s) => s.transport);
	const setConnectOpen = useSession((s) => s.setConnectOpen);
	const tone = tones.find((t) => t.id === activeToneId) ?? tones.find((t) => t.channel === currentChannel);
	function patchTone(partial) {
		if (!tone) return;
		upsertTone({
			...tone,
			...partial
		});
	}
	async function onChannel(ch) {
		try {
			await recallChannel(ch);
			toast.success(transport === "simulator" ? `Demo amp → ${CHANNEL_LABEL[ch]}` : `Amp recalled ${CHANNEL_LABEL[ch]}`);
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Recall failed");
		}
	}
	async function send() {
		if (!tone) return;
		try {
			await sendTone(tone);
			toast.success(`${tone.name} → ${CHANNEL_LABEL[tone.channel]}`);
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Send failed");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AmpPanel, {
			tone,
			channel: currentChannel,
			onChannel: (ch) => void onChannel(ch),
			onTone: patchTone
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 grid grid-cols-2 gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => void send(),
				disabled: !tone,
				children: "Send to amp"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "secondary",
				onClick: () => setConnectOpen(true),
				children: "Connection"
			})]
		}),
		tone ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/tone/$id",
			params: { id: tone.id },
			className: "mt-3 flex min-h-11 items-center justify-center text-sm text-muted",
			children: "Edit recipe"
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-4 text-sm text-muted",
			children: "Channel buttons send a Gen 3 SysEx recall (Panel / CH1–CH8) plus a program change. Map each library tone to the memory you already stored on the amp."
		})
	] });
}
//#endregion
export { PanelPage as component };
