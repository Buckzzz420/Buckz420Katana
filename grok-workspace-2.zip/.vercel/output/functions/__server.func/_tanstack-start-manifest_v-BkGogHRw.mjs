//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BkGogHRw.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/more",
			"/panel",
			"/setlists",
			"/tone/$id"
		],
		preloads: [
			"/assets/index-D0oNo-CN.js",
			"/assets/dist-o86fQukM.js",
			"/assets/preload-helper-BHAZPE_s.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-D0oNo-CN.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-xvfZ6To_.js",
			"/assets/app-shell-C03Tkghu.js",
			"/assets/plus-DjwjrW8m.js",
			"/assets/fx-chain-DKVyCKxK.js",
			"/assets/input-HQiqn6uB.js"
		]
	},
	"/more": {
		filePath: "/workspace/src/routes/more.tsx",
		children: void 0,
		preloads: ["/assets/more-q1LWIeL7.js", "/assets/app-shell-C03Tkghu.js"]
	},
	"/panel": {
		filePath: "/workspace/src/routes/panel.tsx",
		children: void 0,
		preloads: [
			"/assets/panel-DGiK0PZx.js",
			"/assets/app-shell-C03Tkghu.js",
			"/assets/fx-chain-DKVyCKxK.js",
			"/assets/amp-knob-BhhflhMN.js"
		]
	},
	"/setlists": {
		filePath: "/workspace/src/routes/setlists.tsx",
		children: ["/setlists/$id"],
		preloads: [
			"/assets/setlists-CqEn9c5W.js",
			"/assets/app-shell-C03Tkghu.js",
			"/assets/plus-DjwjrW8m.js",
			"/assets/input-HQiqn6uB.js"
		]
	},
	"/setlists/$id": {
		filePath: "/workspace/src/routes/setlists/$id.tsx",
		children: void 0,
		preloads: ["/assets/_id-DRmdmntK.js"]
	},
	"/tone/$id": {
		filePath: "/workspace/src/routes/tone/$id.tsx",
		children: void 0,
		preloads: [
			"/assets/_id-CzG1uYYM.js",
			"/assets/app-shell-C03Tkghu.js",
			"/assets/fx-chain-DKVyCKxK.js",
			"/assets/input-HQiqn6uB.js",
			"/assets/amp-knob-BhhflhMN.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
