import { createFileRoute } from "@tanstack/react-router";
import { useRef } from "react";
import { toast } from "sonner";
import { AppShell } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import { bluetoothSupported, webMidiSupported } from "@/lib/katana/link";
import { useLibrary, useSession } from "@/lib/store";
import type { Setlist, Tone } from "@/lib/katana/types";

export const Route = createFileRoute("/more")({ component: MorePage });

function MorePage() {
  const tones = useLibrary((s) => s.tones);
  const setlists = useLibrary((s) => s.setlists);
  const replaceAll = useLibrary((s) => s.replaceAll);
  const resetFactory = useLibrary((s) => s.resetFactory);
  const log = useSession((s) => s.log);
  const transport = useSession((s) => s.transport);
  const deviceName = useSession((s) => s.deviceName);
  const setConnectOpen = useSession((s) => s.setConnectOpen);
  const fileRef = useRef<HTMLInputElement>(null);

  function exportLibrary() {
    const blob = new Blob(
      [JSON.stringify({ version: 1, tones, setlists }, null, 2)],
      { type: "application/json" },
    );
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "katana-case-library.json";
    a.click();
    URL.revokeObjectURL(url);
    toast.success("Library exported");
  }

  async function onImport(file: File | undefined) {
    if (!file) return;
    try {
      const parsed = JSON.parse(await file.text()) as { tones?: Tone[]; setlists?: Setlist[] };
      if (!Array.isArray(parsed.tones)) throw new Error("No tones in file");
      replaceAll(parsed.tones, Array.isArray(parsed.setlists) ? parsed.setlists : []);
      toast.success(`Imported ${parsed.tones.length} tones`);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Import failed");
    }
  }

  return (
    <AppShell>
      <p className="font-display text-[11px] uppercase tracking-[0.22em] text-muted">Setup</p>
      <h2 className="text-xl font-medium">More</h2>

      <section className="mt-5 rounded-lg bg-surface p-4 shadow-[0_0_0_1px_rgb(255_255_255/0.08)]">
        <h3 className="font-medium">Amp</h3>
        <p className="mt-1 text-sm text-muted">
          {deviceName} · {transport === "simulator" ? "demo" : transport}
        </p>
        <p className="mt-2 text-xs text-subtle">
          Bluetooth {bluetoothSupported() ? "ready" : "not in this browser"} · MIDI{" "}
          {webMidiSupported() ? "ready" : "not in this browser"}
        </p>
        <Button className="mt-3 w-full" variant="secondary" onClick={() => setConnectOpen(true)}>
          Open connection
        </Button>
      </section>

      <section className="mt-3 rounded-lg bg-surface p-4 shadow-[0_0_0_1px_rgb(255_255_255/0.08)]">
        <h3 className="font-medium">Bluetooth MIDI</h3>
        <ol className="mt-2 list-decimal space-y-1.5 pl-4 text-sm text-muted">
          <li>Install the BOSS BT-DUAL in the Katana Gen 3 Bluetooth port.</li>
          <li>Power on. Tap the adaptor once — LED blinks blue slowly (MIDI, not audio).</li>
          <li>On Android, use Chrome. Do not pair KATANA 3 MIDI in system Bluetooth.</li>
          <li>Add this app to your home screen, then Connect from the header pill.</li>
          <li>Sending a tone recalls the mapped Panel / CH1–CH8 memory on the amp.</li>
        </ol>
      </section>

      <section className="mt-3 rounded-lg bg-surface p-4 shadow-[0_0_0_1px_rgb(255_255_255/0.08)]">
        <h3 className="font-medium">Library file</h3>
        <p className="mt-1 text-sm text-muted">JSON backup of tones and setlists on this device.</p>
        <div className="mt-3 grid grid-cols-2 gap-2">
          <Button variant="secondary" onClick={exportLibrary}>
            Export
          </Button>
          <Button variant="secondary" onClick={() => fileRef.current?.click()}>
            Import
          </Button>
        </div>
        <input
          ref={fileRef}
          type="file"
          accept="application/json"
          className="hidden"
          onChange={(e) => void onImport(e.target.files?.[0])}
        />
        <Button
          className="mt-2 w-full"
          variant="ghost"
          onClick={() => {
            resetFactory();
            toast.message("Factory library restored");
          }}
        >
          Restore factory tones
        </Button>
      </section>

      <section className="mt-3 rounded-lg bg-surface p-4 shadow-[0_0_0_1px_rgb(255_255_255/0.08)]">
        <h3 className="font-medium">MIDI log</h3>
        <p className="mt-1 text-sm text-muted">Last messages this session.</p>
        <ul className="mt-3 max-h-56 space-y-2 overflow-y-auto font-mono text-[11px] leading-relaxed text-muted">
          {log.length === 0 ? <li>No traffic yet. Send a tone from the library.</li> : null}
          {log.map((ev) => (
            <li key={ev.id}>
              <span className="text-subtle">{ev.dir === "out" ? "TX" : "RX"}</span> {ev.label}
              <div className="truncate text-subtle">{ev.hex}</div>
            </li>
          ))}
        </ul>
      </section>

      <p className="mt-6 pb-4 text-center text-xs text-subtle">
        Katana Case is an unofficial companion. Katana and BOSS are trademarks of Roland
        Corporation. Store channel memories on the amp; this app recalls them over MIDI.
      </p>
    </AppShell>
  );
}
