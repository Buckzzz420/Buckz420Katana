import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { AppShell } from "@/components/app-shell";
import { ToneForm } from "@/components/tone-form";
import { Button } from "@/components/ui/button";
import { CHANNEL_LABEL, type Tone } from "@/lib/katana/types";
import { newToneDraft, useLibrary, useSession } from "@/lib/store";

export const Route = createFileRoute("/tone/$id")({ component: ToneEditor });

function ToneEditor() {
  const { id } = Route.useParams();
  const navigate = useNavigate();
  const tones = useLibrary((s) => s.tones);
  const upsertTone = useLibrary((s) => s.upsertTone);
  const deleteTone = useLibrary((s) => s.deleteTone);
  const sendTone = useSession((s) => s.sendTone);
  const isNew = id === "new";
  const existing = tones.find((t) => t.id === id);
  const [draft, setDraft] = useState<Tone | null>(null);

  useEffect(() => {
    if (isNew) setDraft(newToneDraft());
    else if (existing) setDraft(existing);
  }, [id, isNew, existing]);

  if (!isNew && !existing) {
    return (
      <AppShell>
        <p className="text-muted">That tone is gone.</p>
      </AppShell>
    );
  }

  if (!draft) {
    return (
      <AppShell>
        <p className="text-muted">Loading recipe…</p>
      </AppShell>
    );
  }

  function patch(partial: Partial<Tone>) {
    setDraft((d) => (d ? { ...d, ...partial } : d));
  }

  function save() {
    if (!draft) return;
    const name = draft.name.trim() || "Untitled tone";
    upsertTone({ ...draft, name });
    toast.success("Saved to library");
    if (isNew) void navigate({ to: "/tone/$id", params: { id: draft.id } });
  }

  async function send() {
    if (!draft) return;
    save();
    try {
      await sendTone(draft);
      toast.success(`Recalled ${CHANNEL_LABEL[draft.channel]}`);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Send failed");
    }
  }

  function remove() {
    if (!draft) return;
    if (isNew) {
      void navigate({ to: "/" });
      return;
    }
    deleteTone(draft.id);
    toast.message("Tone removed");
    void navigate({ to: "/" });
  }

  return (
    <AppShell>
      <div className="mb-4 flex items-center justify-between gap-3">
        <div>
          <p className="font-display text-[11px] uppercase tracking-[0.22em] text-muted">Recipe</p>
          <h2 className="text-xl font-medium">{isNew ? "New tone" : draft.name}</h2>
        </div>
        <Button size="sm" onClick={save}>
          Save
        </Button>
      </div>

      <ToneForm tone={draft} onChange={patch} />

      <div className="mt-6 grid gap-2">
        <Button onClick={() => void send()}>Send to amp</Button>
        <Button variant="ghost" onClick={remove}>
          {isNew ? "Discard" : "Delete tone"}
        </Button>
      </div>
    </AppShell>
  );
}
