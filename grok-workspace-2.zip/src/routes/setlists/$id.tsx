import { createFileRoute, Link } from "@tanstack/react-router";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { AppShell } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { AMP_LABEL, CHANNEL_LABEL } from "@/lib/katana/types";
import { useLibrary, useSession } from "@/lib/store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/setlists/$id")({ component: SetlistPlay });

function SetlistPlay() {
  const { id } = Route.useParams();
  const setlists = useLibrary((s) => s.setlists);
  const tones = useLibrary((s) => s.tones);
  const updateSetlist = useLibrary((s) => s.updateSetlist);
  const sendTone = useSession((s) => s.sendTone);
  const transport = useSession((s) => s.transport);
  const [index, setIndex] = useState(0);

  const setlist = setlists.find((s) => s.id === id);
  const items = useMemo(
    () =>
      setlist
        ? setlist.toneIds
            .map((tid) => tones.find((t) => t.id === tid))
            .filter((t): t is NonNullable<typeof t> => Boolean(t))
        : [],
    [setlist, tones],
  );
  const current = items[index];

  async function go(next: number) {
    if (!items.length) return;
    const wrapped = (next + items.length) % items.length;
    setIndex(wrapped);
    const tone = items[wrapped];
    if (!tone) return;
    try {
      await sendTone(tone);
      toast.success(
        `${tone.name} → ${CHANNEL_LABEL[tone.channel]}${transport === "simulator" ? " (demo)" : ""}`,
      );
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Send failed");
    }
  }

  function addTone(toneId: string) {
    if (!setlist) return;
    if (setlist.toneIds.includes(toneId)) return;
    updateSetlist(setlist.id, { toneIds: [...setlist.toneIds, toneId] });
  }

  function removeAt(i: number) {
    if (!setlist) return;
    updateSetlist(setlist.id, { toneIds: setlist.toneIds.filter((_, idx) => idx !== i) });
    setIndex((n) => Math.max(0, Math.min(n, setlist.toneIds.length - 2)));
  }

  if (!setlist) {
    return (
      <AppShell>
        <p className="text-muted">Setlist missing.</p>
        <Link to="/setlists" className="mt-3 inline-block text-sm">
          Back
        </Link>
      </AppShell>
    );
  }

  return (
    <AppShell>
      <Input
        value={setlist.name}
        onChange={(e) => updateSetlist(setlist.id, { name: e.target.value })}
        className="font-medium"
        aria-label="Setlist name"
      />
      <Input
        value={setlist.venue}
        placeholder="Venue"
        className="mt-2"
        onChange={(e) => updateSetlist(setlist.id, { venue: e.target.value })}
        aria-label="Venue"
      />

      {current ? (
        <div className="mt-5 rounded-xl bg-surface p-5 text-center shadow-[0_0_0_1px_rgb(255_255_255/0.08)]">
          <p className="font-display text-[11px] uppercase tracking-[0.22em] text-muted">
            {index + 1} / {items.length} · {CHANNEL_LABEL[current.channel]}
          </p>
          <h2 className="mt-2 text-2xl font-medium leading-snug break-words">{current.name}</h2>
          <p className="mt-2 text-sm text-muted">
            {AMP_LABEL[current.ampType]} · V{current.variation}
            {current.song ? ` · ${current.song}` : ""}
          </p>
          <div className="mt-6 grid grid-cols-2 gap-2">
            <Button variant="secondary" onClick={() => void go(index - 1)}>
              <ChevronLeft />
              Prev
            </Button>
            <Button onClick={() => void go(index + 1)}>
              Next
              <ChevronRight />
            </Button>
          </div>
          <Button className="mt-2 w-full" variant="led" onClick={() => void go(index)}>
            Send this tone
          </Button>
        </div>
      ) : (
        <p className="mt-6 text-sm text-muted">Add tones below, then step through them on the gig.</p>
      )}

      <h3 className="mt-6 font-display text-[11px] uppercase tracking-[0.18em] text-muted">Order</h3>
      <ol className="mt-2 grid gap-1.5">
        {items.map((tone, i) =>
          tone ? (
            <li
              key={`${tone.id}-${i}`}
              className={cn(
                "flex min-h-12 items-center gap-3 rounded-md px-3",
                i === index ? "bg-led/15" : "bg-raised",
              )}
            >
              <button type="button" className="min-w-0 flex-1 text-left" onClick={() => void go(i)}>
                <span className="block truncate text-sm font-medium">{tone.name}</span>
                <span className="text-xs text-muted">{CHANNEL_LABEL[tone.channel]}</span>
              </button>
              <button type="button" className="text-xs text-muted" onClick={() => removeAt(i)}>
                Drop
              </button>
            </li>
          ) : null,
        )}
      </ol>

      <h3 className="mt-6 font-display text-[11px] uppercase tracking-[0.18em] text-muted">Add from library</h3>
      <ul className="mt-2 grid gap-1.5">
        {tones.map((tone) => (
          <li key={tone.id}>
            <button
              type="button"
              onClick={() => addTone(tone.id)}
              className="flex min-h-11 w-full items-center justify-between rounded-md bg-surface px-3 text-left text-sm shadow-[0_0_0_1px_rgb(255_255_255/0.06)]"
            >
              <span className="truncate">{tone.name}</span>
              <span className="text-xs text-muted">Add</span>
            </button>
          </li>
        ))}
      </ul>
    </AppShell>
  );
}
