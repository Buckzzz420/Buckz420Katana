import { createFileRoute, Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { AmpPanel } from "@/components/amp-panel";
import { AppShell } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import { CHANNEL_LABEL, type Tone } from "@/lib/katana/types";
import { useLibrary, useSession } from "@/lib/store";

export const Route = createFileRoute("/panel")({ component: PanelPage });

function PanelPage() {
  const tones = useLibrary((s) => s.tones);
  const upsertTone = useLibrary((s) => s.upsertTone);
  const currentChannel = useSession((s) => s.currentChannel);
  const recallChannel = useSession((s) => s.recallChannel);
  const activeToneId = useSession((s) => s.activeToneId);
  const sendTone = useSession((s) => s.sendTone);
  const transport = useSession((s) => s.transport);
  const setConnectOpen = useSession((s) => s.setConnectOpen);

  const tone =
    tones.find((t) => t.id === activeToneId) ??
    tones.find((t) => t.channel === currentChannel);

  function patchTone(partial: Partial<Tone>) {
    if (!tone) return;
    upsertTone({ ...tone, ...partial });
  }

  async function onChannel(ch: typeof currentChannel) {
    try {
      await recallChannel(ch);
      toast.success(
        transport === "simulator"
          ? `Demo amp → ${CHANNEL_LABEL[ch]}`
          : `Amp recalled ${CHANNEL_LABEL[ch]}`,
      );
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Recall failed");
    }
  }

  async function send() {
    if (!tone) return;
    try {
      await sendTone(tone);
      toast.success(`${tone.name} → ${CHANNEL_LABEL[tone.channel]}`);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Send failed");
    }
  }

  return (
    <AppShell>
      <AmpPanel
        tone={tone}
        channel={currentChannel}
        onChannel={(ch) => void onChannel(ch)}
        onTone={patchTone}
      />

      <div className="mt-4 grid grid-cols-2 gap-2">
        <Button onClick={() => void send()} disabled={!tone}>
          Send to amp
        </Button>
        <Button variant="secondary" onClick={() => setConnectOpen(true)}>
          Connection
        </Button>
      </div>

      {tone ? (
        <Link
          to="/tone/$id"
          params={{ id: tone.id }}
          className="mt-3 flex min-h-11 items-center justify-center text-sm text-muted"
        >
          Edit recipe
        </Link>
      ) : null}

      <p className="mt-4 text-sm text-muted">
        Channel buttons send a Gen 3 SysEx recall (Panel / CH1–CH8) plus a program change.
        Map each library tone to the memory you already stored on the amp.
      </p>
    </AppShell>
  );
}
