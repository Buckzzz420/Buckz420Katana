import { createFileRoute, Link } from "@tanstack/react-router";
import { Plus } from "lucide-react";
import { useState } from "react";
import { AppShell } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useLibrary } from "@/lib/store";

export const Route = createFileRoute("/setlists")({ component: SetlistsPage });

function SetlistsPage() {
  const setlists = useLibrary((s) => s.setlists);
  const tones = useLibrary((s) => s.tones);
  const addSetlist = useLibrary((s) => s.addSetlist);
  const deleteSetlist = useLibrary((s) => s.deleteSetlist);
  const [name, setName] = useState("");

  function create() {
    const trimmed = name.trim() || "New setlist";
    addSetlist(trimmed);
    setName("");
  }

  return (
    <AppShell>
      <div className="flex items-end justify-between gap-3">
        <div>
          <p className="font-display text-[11px] uppercase tracking-[0.22em] text-muted">Gigs</p>
          <h2 className="text-xl font-medium">Setlists</h2>
        </div>
      </div>

      <div className="mt-4 flex gap-2">
        <Input
          value={name}
          placeholder="Setlist name"
          onChange={(e) => setName(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") create();
          }}
        />
        <Button variant="secondary" size="icon" aria-label="Add setlist" onClick={create}>
          <Plus />
        </Button>
      </div>

      <div className="stagger-in mt-4 grid gap-2.5">
        {setlists.map((sl) => (
          <article
            key={sl.id}
            className="rounded-lg bg-surface p-4 shadow-[0_0_0_1px_rgb(255_255_255/0.08)]"
          >
            <div className="flex items-start justify-between gap-3">
              <Link to="/setlists/$id" params={{ id: sl.id }} className="min-w-0 flex-1">
                <h3 className="truncate text-base font-medium">{sl.name}</h3>
                <p className="mt-0.5 text-sm text-muted">
                  {sl.venue || "No venue"} · {sl.toneIds.length} tones
                </p>
                <p className="mt-2 truncate text-xs text-subtle">
                  {sl.toneIds
                    .map((id) => tones.find((t) => t.id === id)?.name)
                    .filter(Boolean)
                    .join(" · ") || "Empty"}
                </p>
              </Link>
              <button
                type="button"
                className="min-h-11 text-sm text-muted"
                onClick={() => deleteSetlist(sl.id)}
              >
                Remove
              </button>
            </div>
          </article>
        ))}
        {setlists.length === 0 ? (
          <p className="py-10 text-center text-sm text-muted">No setlists yet.</p>
        ) : null}
      </div>
    </AppShell>
  );
}
