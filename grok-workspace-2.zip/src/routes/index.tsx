import { createFileRoute, Link } from "@tanstack/react-router";
import { Plus, Search, Star } from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { AppShell } from "@/components/app-shell";
import { ToneCard } from "@/components/tone-card";
import { Input } from "@/components/ui/input";
import { AMP_LABEL, AMP_TYPES } from "@/lib/katana/types";
import { useLibrary, useSession } from "@/lib/store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/")({ component: LibraryPage });

function LibraryPage() {
  const tones = useLibrary((s) => s.tones);
  const toggleFavorite = useLibrary((s) => s.toggleFavorite);
  const query = useSession((s) => s.query);
  const setQuery = useSession((s) => s.setQuery);
  const ampFilter = useSession((s) => s.ampFilter);
  const setAmpFilter = useSession((s) => s.setAmpFilter);
  const onlyFavs = useSession((s) => s.onlyFavs);
  const setOnlyFavs = useSession((s) => s.setOnlyFavs);
  const sendTone = useSession((s) => s.sendTone);
  const transport = useSession((s) => s.transport);
  const [sendingId, setSendingId] = useState<string | null>(null);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return tones.filter((tone) => {
      if (onlyFavs && !tone.favorite) return false;
      if (ampFilter !== "all" && tone.ampType !== ampFilter) return false;
      if (!q) return true;
      const hay = `${tone.name} ${tone.song} ${tone.notes} ${tone.tags.join(" ")}`.toLowerCase();
      return hay.includes(q);
    });
  }, [tones, query, ampFilter, onlyFavs]);

  async function send(id: string) {
    const tone = tones.find((t) => t.id === id);
    if (!tone) return;
    setSendingId(id);
    try {
      await sendTone(tone);
      const dest = tone.channel === 0 ? "Panel" : `CH${tone.channel}`;
      toast.success(
        transport === "simulator"
          ? `${tone.name} → ${dest} on the demo amp`
          : `${tone.name} recalled ${dest}`,
      );
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Send failed");
    } finally {
      setSendingId(null);
    }
  }

  return (
    <AppShell>
      <div className="relative">
        <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-subtle" />
        <Input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search tones, songs, tags"
          className="pl-10"
          aria-label="Search tones"
        />
      </div>

      <div className="mt-3 flex gap-1.5 overflow-x-auto pb-1">
        <FilterChip active={ampFilter === "all" && !onlyFavs} onClick={() => { setAmpFilter("all"); setOnlyFavs(false); }}>
          All
        </FilterChip>
        <FilterChip active={onlyFavs} onClick={() => setOnlyFavs(!onlyFavs)}>
          <Star className={cn("size-3", onlyFavs && "fill-current")} />
          Favs
        </FilterChip>
        {AMP_TYPES.map((type) => (
          <FilterChip
            key={type}
            active={ampFilter === type}
            onClick={() => setAmpFilter(ampFilter === type ? "all" : type)}
          >
            {AMP_LABEL[type]}
          </FilterChip>
        ))}
      </div>

      <div className="mt-4 flex items-baseline justify-between">
        <p className="text-sm text-muted">
          {filtered.length} tone{filtered.length === 1 ? "" : "s"}
        </p>
        <Link
          to="/tone/$id"
          params={{ id: "new" }}
          className="inline-flex min-h-11 items-center gap-1.5 text-sm font-medium text-fg"
        >
          <Plus className="size-4" />
          New tone
        </Link>
      </div>

      <div className="stagger-in mt-3 grid gap-2.5">
        {filtered.map((tone) => (
          <ToneCard
            key={tone.id}
            tone={tone}
            sending={sendingId === tone.id}
            onFav={() => toggleFavorite(tone.id)}
            onSend={() => void send(tone.id)}
          />
        ))}
        {filtered.length === 0 ? (
          <div className="rounded-lg bg-surface px-4 py-10 text-center shadow-[0_0_0_1px_rgb(255_255_255/0.08)]">
            <p className="font-medium">No tones match</p>
            <p className="mt-1 text-sm text-muted">Clear filters or add a new recipe.</p>
          </div>
        ) : null}
      </div>
    </AppShell>
  );
}

function FilterChip({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "inline-flex h-9 shrink-0 items-center gap-1.5 rounded-full px-3 text-sm transition-colors duration-150",
        active ? "bg-accent text-accent-fg" : "bg-raised text-muted",
      )}
    >
      {children}
    </button>
  );
}
