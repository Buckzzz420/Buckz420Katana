import { create } from "zustand";
import { persist } from "zustand/middleware";
import { FACTORY_SETLISTS, FACTORY_TONES } from "@/lib/katana/factory";
import { KatanaLink } from "@/lib/katana/link";
import type {
  AmpType,
  Channel,
  LinkStatus,
  LinkTransport,
  MidiEvent,
  Setlist,
  Tone,
} from "@/lib/katana/types";
import { blankTone } from "@/lib/katana/types";
import { uid } from "@/lib/utils";

interface LibraryState {
  tones: Tone[];
  setlists: Setlist[];
  upsertTone: (tone: Tone) => void;
  deleteTone: (id: string) => void;
  toggleFavorite: (id: string) => void;
  addSetlist: (name: string, venue?: string) => string;
  updateSetlist: (id: string, patch: Partial<Setlist>) => void;
  deleteSetlist: (id: string) => void;
  resetFactory: () => void;
  replaceAll: (tones: Tone[], setlists: Setlist[]) => void;
}

export const useLibrary = create<LibraryState>()(
  persist(
    (set) => ({
      tones: FACTORY_TONES,
      setlists: FACTORY_SETLISTS,
      upsertTone: (tone) =>
        set((s) => {
          const idx = s.tones.findIndex((t) => t.id === tone.id);
          const next = [...s.tones];
          const saved = { ...tone, updatedAt: Date.now() };
          if (idx >= 0) next[idx] = saved;
          else next.unshift(saved);
          return { tones: next };
        }),
      deleteTone: (id) =>
        set((s) => ({
          tones: s.tones.filter((t) => t.id !== id),
          setlists: s.setlists.map((sl) => ({
            ...sl,
            toneIds: sl.toneIds.filter((tid) => tid !== id),
          })),
        })),
      toggleFavorite: (id) =>
        set((s) => ({
          tones: s.tones.map((t) => (t.id === id ? { ...t, favorite: !t.favorite, updatedAt: Date.now() } : t)),
        })),
      addSetlist: (name, venue = "") => {
        const id = uid("set");
        set((s) => ({
          setlists: [{ id, name, venue, toneIds: [], createdAt: Date.now() }, ...s.setlists],
        }));
        return id;
      },
      updateSetlist: (id, patch) =>
        set((s) => ({
          setlists: s.setlists.map((sl) => (sl.id === id ? { ...sl, ...patch } : sl)),
        })),
      deleteSetlist: (id) => set((s) => ({ setlists: s.setlists.filter((sl) => sl.id !== id) })),
      resetFactory: () => set({ tones: FACTORY_TONES, setlists: FACTORY_SETLISTS }),
      replaceAll: (tones, setlists) => set({ tones, setlists }),
    }),
    { name: "katana-case-library", skipHydration: true },
  ),
);

interface SessionState {
  hydrated: boolean;
  setHydrated: () => void;
  query: string;
  ampFilter: AmpType | "all";
  onlyFavs: boolean;
  setQuery: (q: string) => void;
  setAmpFilter: (f: AmpType | "all") => void;
  setOnlyFavs: (v: boolean) => void;
  activeToneId: string | null;
  setActiveToneId: (id: string | null) => void;
  currentChannel: Channel;
  setCurrentChannel: (ch: Channel) => void;
  status: LinkStatus;
  transport: LinkTransport;
  deviceName: string;
  error: string | null;
  log: MidiEvent[];
  connectOpen: boolean;
  setConnectOpen: (v: boolean) => void;
  connectBluetooth: (anyDevice?: boolean) => Promise<void>;
  connectWebMidi: () => Promise<void>;
  useSimulator: () => void;
  disconnect: () => void;
  recallChannel: (ch: Channel) => Promise<void>;
  sendTone: (tone: Tone) => Promise<void>;
}

let link: KatanaLink | null = null;

function getLink(): KatanaLink {
  if (!link) {
    link = new KatanaLink(
      (event) =>
        useSession.setState((s) => ({
          log: [event, ...s.log].slice(0, 40),
        })),
      () =>
        useSession.setState({
          status: "connected",
          transport: "simulator",
          deviceName: "Katana 50 Gen 3 (Demo)",
          error: "Amp disconnected — back on the demo amp.",
        }),
    );
  }
  return link;
}

export const useSession = create<SessionState>()((set, get) => ({
  hydrated: false,
  setHydrated: () => set({ hydrated: true }),
  query: "",
  ampFilter: "all",
  onlyFavs: false,
  setQuery: (query) => set({ query }),
  setAmpFilter: (ampFilter) => set({ ampFilter }),
  setOnlyFavs: (onlyFavs) => set({ onlyFavs }),
  activeToneId: FACTORY_TONES[0]?.id ?? null,
  setActiveToneId: (activeToneId) => set({ activeToneId }),
  currentChannel: 1,
  setCurrentChannel: (currentChannel) => set({ currentChannel }),
  status: "connected",
  transport: "simulator",
  deviceName: "Katana 50 Gen 3 (Demo)",
  error: null,
  log: [],
  connectOpen: false,
  setConnectOpen: (connectOpen) => set({ connectOpen }),
  connectBluetooth: async (anyDevice = false) => {
    set({ status: "connecting", error: null });
    try {
      const name = anyDevice
        ? await getLink().connectBluetoothAny()
        : await getLink().connectBluetooth();
      set({
        status: "connected",
        transport: getLink().transport,
        deviceName: name,
        error: null,
      });
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Could not connect";
      getLink().useSimulator();
      set({
        status: "connected",
        transport: "simulator",
        deviceName: "Katana 50 Gen 3 (Demo)",
        error: msg,
      });
      throw err;
    }
  },
  connectWebMidi: async () => {
    set({ status: "connecting", error: null });
    try {
      const name = await getLink().connectWebMidi();
      set({
        status: "connected",
        transport: getLink().transport,
        deviceName: name,
        error: null,
      });
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Could not connect";
      getLink().useSimulator();
      set({
        status: "connected",
        transport: "simulator",
        deviceName: "Katana 50 Gen 3 (Demo)",
        error: msg,
      });
      throw err;
    }
  },
  useSimulator: () => {
    getLink().useSimulator();
    set({
      status: "connected",
      transport: "simulator",
      deviceName: "Katana 50 Gen 3 (Demo)",
      error: null,
    });
  },
  disconnect: () => {
    getLink().disconnect();
    set({
      status: "connected",
      transport: "simulator",
      deviceName: "Katana 50 Gen 3 (Demo)",
      error: null,
    });
  },
  recallChannel: async (ch) => {
    set({ currentChannel: ch });
    const tones = useLibrary.getState().tones;
    const mapped = tones.find((t) => t.id === get().activeToneId && t.channel === ch)
      ?? tones.find((t) => t.channel === ch);
    if (mapped) set({ activeToneId: mapped.id });
    await getLink().recallChannel(ch);
  },
  sendTone: async (tone) => {
    set({ activeToneId: tone.id, currentChannel: tone.channel });
    await getLink().recallChannel(tone.channel);
  },
}));

export function newToneDraft(): Tone {
  return blankTone(uid("tone"));
}
