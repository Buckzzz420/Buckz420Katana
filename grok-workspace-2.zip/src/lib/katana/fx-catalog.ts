export const BOOSTER_TYPES = [
  "Clean Boost",
  "Treble Boost",
  "Mid Boost",
  "Blues Drive",
  "Overdrive",
  "T-Scream",
  "Turbo OD",
  "Distortion",
  "Fat DS",
  "Metal DS",
  "Oct Fuzz",
  "Blues OD",
] as const;

export const MOD_TYPES = [
  "Chorus",
  "Flanger",
  "Phaser",
  "Uni-V",
  "Tremolo",
  "Vibrato",
  "Rotary",
  "Ring Mod",
  "Slicer",
] as const;

export const FX_TYPES = [
  "Compressor",
  "T.Wah",
  "Auto Wah",
  "Octave",
  "Pitch Shifter",
  "Harmonist",
  "Guitar Sim",
  "Slow Gear",
  "Defretter",
  "Wav Synth",
] as const;

export const DELAY_TYPES = [
  "Digital",
  "Analog",
  "Tape Echo",
  "Reverse",
  "Modulation",
  "SDE-3000",
  "Warm",
  "Slap",
] as const;

export const REVERB_TYPES = [
  "Ambience",
  "Room",
  "Hall",
  "Plate",
  "Spring",
  "Modulate",
  "Cathedral",
] as const;

export const TAGS = [
  "gig",
  "studio",
  "practice",
  "blues",
  "rock",
  "metal",
  "country",
  "funk",
  "ambient",
  "acoustic",
  "lead",
  "rhythm",
] as const;
