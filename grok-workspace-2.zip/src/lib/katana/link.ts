import { uid } from "@/lib/utils";
import {
  BLE_MIDI_CHAR,
  BLE_MIDI_SERVICE,
  editorModeOn,
  encodeBleMidi,
  programChange,
  selectPatch,
  toHex,
} from "./sysex";
import type { Channel, LinkTransport, MidiEvent } from "./types";

export type LogFn = (event: MidiEvent) => void;

function midiEvent(dir: MidiEvent["dir"], label: string, bytes: number[]): MidiEvent {
  return { id: uid("midi"), at: Date.now(), dir, label, hex: toHex(bytes) };
}

export function bluetoothSupported(): boolean {
  return typeof navigator !== "undefined" && "bluetooth" in navigator;
}

export function webMidiSupported(): boolean {
  return typeof navigator !== "undefined" && "requestMIDIAccess" in navigator;
}

type MidiOutput = {
  send: (data: number[] | Uint8Array) => void;
  name?: string | null;
};

type BleChar = {
  writeValueWithoutResponse?: (data: BufferSource) => Promise<void>;
  writeValue: (data: BufferSource) => Promise<void>;
  startNotifications: () => Promise<BleChar>;
  addEventListener: (type: string, listener: (ev: Event) => void) => void;
};

export class KatanaLink {
  transport: LinkTransport = "simulator";
  deviceName = "Katana 50 Gen 3 (Demo)";
  private bleDevice: BluetoothDevice | null = null;
  private bleChar: BleChar | null = null;
  private midiOut: MidiOutput | null = null;
  private midiAccess: MIDIAccess | null = null;
  private log: LogFn;
  private onDropped: () => void;

  constructor(log: LogFn, onDropped: () => void) {
    this.log = log;
    this.onDropped = onDropped;
  }

  async sendBytes(bytes: number[], label: string): Promise<void> {
    this.log(midiEvent("out", label, bytes));
    if (this.transport === "simulator") return;

    if (this.transport === "webmidi" && this.midiOut) {
      this.midiOut.send(bytes);
      return;
    }

    if (this.transport === "bluetooth" && this.bleChar) {
      const packet = encodeBleMidi(bytes);
      const buffer = packet.buffer.slice(packet.byteOffset, packet.byteOffset + packet.byteLength) as ArrayBuffer;
      try {
        if (this.bleChar.writeValueWithoutResponse) {
          await this.bleChar.writeValueWithoutResponse(buffer);
        } else {
          await this.bleChar.writeValue(buffer);
        }
      } catch (err) {
        throw new Error(err instanceof Error ? err.message : "Bluetooth write failed");
      }
    }
  }

  async recallChannel(channel: Channel): Promise<void> {
    await this.sendBytes(editorModeOn(), "Editor mode");
    await this.sendBytes(selectPatch(channel), `Recall ${channel === 0 ? "Panel" : `CH${channel}`}`);
    await this.sendBytes(programChange(channel), `Program change ${channel}`);
  }

  useSimulator(): void {
    this.disconnectHardware();
    this.transport = "simulator";
    this.deviceName = "Katana 50 Gen 3 (Demo)";
  }

  async connectBluetooth(): Promise<string> {
    if (!bluetoothSupported()) {
      throw new Error("Web Bluetooth is not available. Use Chrome on Android.");
    }

    const nav = navigator as Navigator & { bluetooth: Bluetooth };
    const device = await nav.bluetooth.requestDevice({
      filters: [
        { namePrefix: "KATANA" },
        { namePrefix: "Katana" },
        { namePrefix: "BT-DUAL" },
        { services: [BLE_MIDI_SERVICE] },
      ],
      optionalServices: [BLE_MIDI_SERVICE],
    });

    const server = await device.gatt!.connect();
    const service = await server.getPrimaryService(BLE_MIDI_SERVICE);
    const characteristic = (await service.getCharacteristic(BLE_MIDI_CHAR)) as unknown as BleChar;
    try {
      await characteristic.startNotifications();
    } catch {
      // Some stacks allow writes without notify.
    }

    this.disconnectHardware();
    this.bleDevice = device;
    this.bleChar = characteristic;
    this.transport = "bluetooth";
    this.deviceName = device.name?.trim() || "KATANA 3 MIDI";
    device.addEventListener("gattserverdisconnected", () => {
      if (this.bleDevice === device) {
        this.transport = "simulator";
        this.deviceName = "Katana 50 Gen 3 (Demo)";
        this.bleDevice = null;
        this.bleChar = null;
        this.onDropped();
      }
    });

    await this.sendBytes(editorModeOn(), "Editor mode");
    return this.deviceName;
  }

  async connectBluetoothAny(): Promise<string> {
    if (!bluetoothSupported()) {
      throw new Error("Web Bluetooth is not available. Use Chrome on Android.");
    }
    const nav = navigator as Navigator & { bluetooth: Bluetooth };
    const device = await nav.bluetooth.requestDevice({
      acceptAllDevices: true,
      optionalServices: [BLE_MIDI_SERVICE],
    });
    const server = await device.gatt!.connect();
    const service = await server.getPrimaryService(BLE_MIDI_SERVICE);
    const characteristic = (await service.getCharacteristic(BLE_MIDI_CHAR)) as unknown as BleChar;
    try {
      await characteristic.startNotifications();
    } catch {
      /* ignore */
    }
    this.disconnectHardware();
    this.bleDevice = device;
    this.bleChar = characteristic;
    this.transport = "bluetooth";
    this.deviceName = device.name?.trim() || "BLE MIDI";
    device.addEventListener("gattserverdisconnected", () => {
      if (this.bleDevice === device) {
        this.transport = "simulator";
        this.deviceName = "Katana 50 Gen 3 (Demo)";
        this.bleDevice = null;
        this.bleChar = null;
        this.onDropped();
      }
    });
    await this.sendBytes(editorModeOn(), "Editor mode");
    return this.deviceName;
  }

  async connectWebMidi(): Promise<string> {
    if (!webMidiSupported()) {
      throw new Error("Web MIDI is not available in this browser.");
    }
    const access = await navigator.requestMIDIAccess({ sysex: true });
    this.midiAccess = access;
    const outputs = [...access.outputs.values()];
    const preferred =
      outputs.find((o) => /katana/i.test(o.name ?? "")) ??
      outputs.find((o) => /boss|roland/i.test(o.name ?? "")) ??
      outputs[0];
    if (!preferred) {
      throw new Error("No MIDI outputs found. Plug in USB or pair KATANA 3 MIDI first.");
    }
    this.disconnectHardware();
    this.midiOut = preferred;
    this.transport = "webmidi";
    this.deviceName = preferred.name || "MIDI output";
    await this.sendBytes(editorModeOn(), "Editor mode");
    return this.deviceName;
  }

  listWebMidiOutputs(): string[] {
    if (!this.midiAccess) return [];
    return [...this.midiAccess.outputs.values()].map((o) => o.name || "MIDI");
  }

  private disconnectHardware(): void {
    try {
      this.bleDevice?.gatt?.disconnect();
    } catch {
      /* ignore */
    }
    this.bleDevice = null;
    this.bleChar = null;
    this.midiOut = null;
  }

  disconnect(): void {
    this.disconnectHardware();
    this.useSimulator();
  }
}
