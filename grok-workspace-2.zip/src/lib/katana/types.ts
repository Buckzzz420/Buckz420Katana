export const AMP_TYPES = ["clean", "crunch", "lead", "brown", "acoustic"] as const;
export type AmpType = (typeof AMP_TYPES)[number];

export const CHANNELS = [0, 1, 2, 3, 4, 5, 6, 7, 8] as const;
export type Channel = (typeof CHANNELS)[number];

export type Variation = 1 | 2;

export interface Knobs {
  gain: number;
  volume: number;
  bass: number;
  middle: number;
  treble: number;
  presence: number;
  contour: number;
  master: number;
}

export interface FxBlock {
  on: boolean;
  type: string;
}

export interface DelayBlock extends FxBlock {
  timeMs: number;
}

export interface FxChain {
  booster: FxBlock;
  mod: FxBlock;
  fx: FxBlock;
  delay: DelayBlock;
  reverb: FxBlock;
}

export interface Tone {
  id: string;
  name: string;
  song: string;
  notes: string;
  favorite: boolean;
  tags: string[];
  channel: Channel;
  ampType: AmpType;
  variation: Variation;
  knobs: Knobs;
  fx: FxChain;
  createdAt: number;
  updatedAt: number;
}

export interface Setlist {
  id: string;
  name: string;
  venue: string;
  toneIds: string[];
  createdAt: number;
}

export type LinkTransport = "simulator" | "bluetooth" | "webmidi";
export type LinkStatus = "disconnected" | "connecting" | "connected";

export interface MidiEvent {
  id: string;
  at: number;
  dir: "out" | "in";
  label: string;
  hex: string;
}

export const AMP_LABEL: Record<AmpType, string> = {
  clean: "Clean",
  crunch: "Crunch",
  lead: "Lead",
  brown: "Brown",
  acoustic: "Acoustic",
};

export const CHANNEL_LABEL: Record<Channel, string> = {
  0: "Panel",
  1: "CH1",
  2: "CH2",
  3: "CH3",
  4: "CH4",
  5: "CH5",
  6: "CH6",
  7: "CH7",
  8: "CH8",
};

export const KNOB_META: { key: keyof Knobs; label: string }[] = [
  { key: "gain", label: "Gain" },
  { key: "volume", label: "Volume" },
  { key: "bass", label: "Bass" },
  { key: "middle", label: "Middle" },
  { key: "treble", label: "Treble" },
  { key: "presence", label: "Presence" },
  { key: "contour", label: "Contour" },
  { key: "master", label: "Master" },
];

export const FX_ORDER = ["booster", "mod", "fx", "delay", "reverb"] as const;
export type FxKey = (typeof FX_ORDER)[number];

export const FX_LABEL: Record<FxKey, string> = {
  booster: "Boost",
  mod: "Mod",
  fx: "FX",
  delay: "Delay",
  reverb: "Rev",
};

export function emptyKnobs(): Knobs {
  return {
    gain: 50,
    volume: 50,
    bass: 50,
    middle: 50,
    treble: 50,
    presence: 50,
    contour: 50,
    master: 40,
  };
}

export function emptyFx(): FxChain {
  return {
    booster: { on: false, type: "Clean Boost" },
    mod: { on: false, type: "Chorus" },
    fx: { on: false, type: "Compressor" },
    delay: { on: false, type: "Digital", timeMs: 380 },
    reverb: { on: false, type: "Hall" },
  };
}

export function blankTone(id: string): Tone {
  const now = Date.now();
  return {
    id,
    name: "Untitled tone",
    song: "",
    notes: "",
    favorite: false,
    tags: [],
    channel: 1,
    ampType: "clean",
    variation: 1,
    knobs: emptyKnobs(),
    fx: emptyFx(),
    createdAt: now,
    updatedAt: now,
  };
}
