/** Roland/BOSS Katana Gen 3 SysEx helpers (community-confirmed). */

export const GEN3_DT1 = [0xf0, 0x41, 0x10, 0x01, 0x05, 0x07, 0x12] as const;

export function toHex(bytes: number[] | Uint8Array): string {
  return Array.from(bytes)
    .map((b) => b.toString(16).padStart(2, "0"))
    .join(" ")
    .toUpperCase();
}

/** Roland checksum: 128 − (sum of address+data modulo 128). */
export function rolandChecksum(bytes: number[]): number {
  const sum = bytes.reduce((a, b) => a + (b & 0x7f), 0);
  return (128 - (sum % 128)) & 0x7f;
}

export function dt1(address: number[], data: number[]): number[] {
  const payload = [...address, ...data];
  return [...GEN3_DT1, ...payload, rolandChecksum(payload), 0xf7];
}

/** Put the amp in editor (verbose) mode so it accepts patch recalls. */
export function editorModeOn(): number[] {
  return dt1([0x7f, 0x00, 0x00, 0x01], [0x01]);
}

export function editorModeOff(): number[] {
  return dt1([0x7f, 0x00, 0x00, 0x01], [0x00]);
}

/**
 * Recall Panel (0) or channel memory 1–8.
 * Confirmed Gen 3: F0 41 10 01 05 07 12 7F 00 01 00 00 nn cs F7
 */
export function selectPatch(channel: number): number[] {
  const n = Math.max(0, Math.min(8, channel | 0));
  return dt1([0x7f, 0x00, 0x01, 0x00], [n]);
}

export function programChange(program: number, midiChannel = 0): number[] {
  const p = Math.max(0, Math.min(127, program | 0));
  return [0xc0 | (midiChannel & 0x0f), p];
}

/** BLE-MIDI wraps each MIDI message with a 13-bit millisecond timestamp. */
export function encodeBleMidi(message: number[]): Uint8Array {
  const t = Date.now() % 8192;
  const header = 0x80 | ((t >> 7) & 0x3f);
  const timestamp = 0x80 | (t & 0x7f);
  return new Uint8Array([header, timestamp, ...message]);
}

export const BLE_MIDI_SERVICE = "03b80e5a-ede8-4b33-a751-6ce34ec4c700";
export const BLE_MIDI_CHAR = "7772e5db-3868-4112-a1a9-f2669d106bf3";
