import { CHANNELS, CHANNEL_LABEL, type Channel } from "@/lib/katana/types";
import { cn } from "@/lib/utils";

export function ChannelStrip({
  current,
  onSelect,
}: {
  current: Channel;
  onSelect: (ch: Channel) => void;
}) {
  return (
    <div className="grid grid-cols-9 gap-1">
      {CHANNELS.map((ch) => {
        const on = current === ch;
        return (
          <button
            key={ch}
            type="button"
            onClick={() => onSelect(ch)}
            className={cn(
              "flex min-h-12 flex-col items-center justify-center gap-1 rounded-sm transition-[background-color,box-shadow] duration-150 ease-out",
              on
                ? "bg-led/15 shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-led)_55%,transparent)]"
                : "bg-raised shadow-[0_0_0_1px_rgb(255_255_255/0.06)]",
            )}
          >
            <span className={cn("led-pip", on && "on")} />
            <span className="font-display text-[9px] uppercase tracking-[0.12em] text-fg">
              {CHANNEL_LABEL[ch]}
            </span>
          </button>
        );
      })}
    </div>
  );
}
