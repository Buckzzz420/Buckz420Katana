import { AmpKnob } from "@/components/amp-knob";
import { ChannelStrip } from "@/components/channel-strip";
import { FxToggleRow } from "@/components/fx-chain";
import { AMP_LABEL, AMP_TYPES, KNOB_META, type AmpType, type Channel, type FxKey, type Tone } from "@/lib/katana/types";
import { cn } from "@/lib/utils";

export function AmpPanel({
  tone,
  channel,
  onChannel,
  onTone,
}: {
  tone: Tone | undefined;
  channel: Channel;
  onChannel: (ch: Channel) => void;
  onTone: (patch: Partial<Tone>) => void;
}) {
  return (
    <section className="rounded-xl bg-surface p-4 shadow-[0_0_0_1px_rgb(255_255_255/0.08)]">
      <div className="mb-4 flex items-end justify-between gap-3">
        <div>
          <p className="font-display text-[11px] uppercase tracking-[0.22em] text-muted">Front panel</p>
          <h2 className="mt-0.5 text-lg font-medium">{tone?.name ?? "No tone on this channel"}</h2>
        </div>
        {tone ? (
          <span className="font-display text-xs uppercase tracking-[0.14em] text-muted">
            {AMP_LABEL[tone.ampType]} V{tone.variation}
          </span>
        ) : null}
      </div>

      <ChannelStrip current={channel} onSelect={onChannel} />

      {tone ? (
        <>
          <div className="mt-4 grid grid-cols-5 gap-1.5">
            {AMP_TYPES.map((type) => (
              <AmpTypeKey
                key={type}
                type={type}
                active={tone.ampType === type}
                onClick={() => onTone({ ampType: type })}
              />
            ))}
          </div>

          <div className="mt-3 grid grid-cols-2 gap-1.5">
            {([1, 2] as const).map((v) => (
              <button
                key={v}
                type="button"
                onClick={() => onTone({ variation: v })}
                className={cn(
                  "flex min-h-11 items-center justify-center gap-2 rounded-md text-sm transition-colors duration-150",
                  tone.variation === v
                    ? "bg-accent text-accent-fg"
                    : "bg-raised text-muted shadow-[0_0_0_1px_rgb(255_255_255/0.06)]",
                )}
              >
                Variation {v}
              </button>
            ))}
          </div>

          <div className="mt-5 flex gap-1 overflow-x-auto pb-1">
            {KNOB_META.map((k) => (
              <AmpKnob
                key={k.key}
                label={k.label}
                value={tone.knobs[k.key]}
                onChange={(value) => onTone({ knobs: { ...tone.knobs, [k.key]: value } })}
              />
            ))}
          </div>

          <div className="mt-5">
            <FxToggleRow
              fx={tone.fx}
              onToggle={(key: FxKey) =>
                onTone({ fx: { ...tone.fx, [key]: { ...tone.fx[key], on: !tone.fx[key].on } } })
              }
            />
          </div>
        </>
      ) : (
        <p className="mt-6 text-sm text-muted">
          Map a library tone to this channel, then send it. The hardware recall hits Panel or CH1–CH8.
        </p>
      )}
    </section>
  );
}

function AmpTypeKey({
  type,
  active,
  onClick,
}: {
  type: AmpType;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "flex min-h-12 flex-col items-center justify-center gap-1 rounded-md px-1 transition-[background-color] duration-150",
        active ? "bg-led/15" : "bg-raised shadow-[0_0_0_1px_rgb(255_255_255/0.06)]",
      )}
    >
      <span className={cn("led-pip", active && "on")} />
      <span className="font-display text-[9px] uppercase tracking-[0.12em]">{AMP_LABEL[type]}</span>
    </button>
  );
}
