import { Link, useRouterState } from "@tanstack/react-router";
import { AudioLines, Library, ListMusic, MoreHorizontal } from "lucide-react";
import { useEffect } from "react";
import { ConnectSheet } from "@/components/connect-sheet";
import { useLibrary, useSession } from "@/lib/store";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/", label: "Library", icon: Library, exact: true },
  { to: "/panel", label: "Panel", icon: AudioLines, exact: false },
  { to: "/setlists", label: "Setlists", icon: ListMusic, exact: false },
  { to: "/more", label: "More", icon: MoreHorizontal, exact: false },
] as const;

export function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const setHydrated = useSession((s) => s.setHydrated);
  const hydrated = useSession((s) => s.hydrated);
  const transport = useSession((s) => s.transport);
  const deviceName = useSession((s) => s.deviceName);
  const setConnectOpen = useSession((s) => s.setConnectOpen);

  useEffect(() => {
    void useLibrary.persist.rehydrate();
    setHydrated();
  }, [setHydrated]);

  const live = transport !== "simulator";

  return (
    <div className="app-shell mx-auto flex max-w-lg flex-col bg-bg">
      <header className="sticky top-0 z-30 flex items-center gap-3 border-b border-border bg-bg/95 px-4 pb-3 pt-[max(0.75rem,env(safe-area-inset-top))] backdrop-blur-sm">
        <div className="min-w-0 flex-1">
          <p className="font-display text-[11px] uppercase tracking-[0.28em] text-muted">Katana Gen 3</p>
          <h1 className="font-display text-xl uppercase tracking-[0.12em] text-fg">Katana Case</h1>
        </div>
        <button
          type="button"
          onClick={() => setConnectOpen(true)}
          className="flex min-h-11 max-w-[11rem] items-center gap-2 rounded-full bg-raised px-3 py-1.5 text-left shadow-[0_0_0_1px_rgb(255_255_255/0.08)]"
        >
          <span className={cn("led-pip shrink-0", live && "on")} />
          <span className="min-w-0">
            <span className="block truncate text-xs font-medium text-fg">
              {live ? "Live" : "Demo"}
            </span>
            <span className="block truncate text-[10px] text-muted">{deviceName}</span>
          </span>
        </button>
      </header>

      <div className="flex-1 px-4 pb-28 pt-4">{hydrated ? children : children}</div>

      <nav className="fixed inset-x-0 bottom-0 z-30 mx-auto max-w-lg border-t border-border bg-bg/95 pb-[max(0.4rem,env(safe-area-inset-bottom))] pt-1 backdrop-blur-sm">
        <ul className="grid grid-cols-4">
          {NAV.map((item) => {
            const active = item.exact ? pathname === item.to : pathname.startsWith(item.to);
            const Icon = item.icon;
            return (
              <li key={item.to}>
                <Link
                  to={item.to}
                  className={cn(
                    "flex min-h-12 flex-col items-center justify-center gap-0.5 text-[11px] font-medium",
                    active ? "text-fg" : "text-muted",
                  )}
                >
                  <Icon className="size-5" strokeWidth={active ? 2.2 : 1.8} />
                  {item.label}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>
      <ConnectSheet />
    </div>
  );
}
