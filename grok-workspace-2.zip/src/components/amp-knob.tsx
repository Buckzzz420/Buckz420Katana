import { useRef } from "react";
import { clamp, cn } from "@/lib/utils";

export function AmpKnob({
  label,
  value,
  onChange,
  disabled,
}: {
  label: string;
  value: number;
  onChange: (v: number) => void;
  disabled?: boolean;
}) {
  const live = useRef(value);
  live.current = value;
  const lastY = useRef(0);
  const dragging = useRef(false);
  const angle = -135 + (clamp(value, 0, 100) / 100) * 270;

  return (
    <div className="flex w-[4.5rem] flex-col items-center gap-2">
      <button
        type="button"
        disabled={disabled}
        aria-label={`${label} ${Math.round(value)}`}
        className={cn(
          "relative size-14 touch-none rounded-full bg-raised shadow-[0_0_0_1px_rgb(255_255_255/0.1),inset_0_1px_0_rgb(255_255_255/0.08)]",
          "transition-transform duration-150 ease-out active:scale-[0.96]",
          disabled && "opacity-50",
        )}
        onPointerDown={(e) => {
          dragging.current = true;
          lastY.current = e.clientY;
          (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
        }}
        onPointerMove={(e) => {
          if (!dragging.current) return;
          const next = clamp(live.current - (e.clientY - lastY.current) * 0.45, 0, 100);
          lastY.current = e.clientY;
          live.current = next;
          onChange(next);
        }}
        onPointerUp={() => {
          dragging.current = false;
        }}
        onPointerCancel={() => {
          dragging.current = false;
        }}
        onKeyDown={(e) => {
          if (e.key === "ArrowUp" || e.key === "ArrowRight") {
            e.preventDefault();
            onChange(clamp(value + 2, 0, 100));
          }
          if (e.key === "ArrowDown" || e.key === "ArrowLeft") {
            e.preventDefault();
            onChange(clamp(value - 2, 0, 100));
          }
        }}
      >
        <span className="absolute inset-[3px] rounded-full bg-surface" />
        <span className="absolute inset-0" style={{ transform: `rotate(${angle}deg)` }}>
          <span className="absolute left-1/2 top-1.5 h-4 w-[2px] -translate-x-1/2 rounded-full bg-accent" />
        </span>
      </button>
      <div className="text-center">
        <div className="font-display text-[11px] uppercase tracking-[0.14em] text-muted">{label}</div>
        <div className="font-mono text-xs tabular-nums text-fg">{Math.round(value)}</div>
      </div>
    </div>
  );
}
