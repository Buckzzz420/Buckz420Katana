import { Link } from "@tanstack/react-router";
import { Star } from "lucide-react";
import { FxChainPips } from "@/components/fx-chain";
import { Button } from "@/components/ui/button";
import { AMP_LABEL, CHANNEL_LABEL, type Tone } from "@/lib/katana/types";
import { cn } from "@/lib/utils";

export function ToneCard({
  tone,
  onSend,
  onFav,
  sending,
}: {
  tone: Tone;
  onSend: () => void;
  onFav: () => void;
  sending?: boolean;
}) {
  return (
    <article className="rounded-lg bg-surface p-3 shadow-[0_0_0_1px_rgb(255_255_255/0.08)]">
      <div className="flex items-start gap-3">
        <Link
          to="/tone/$id"
          params={{ id: tone.id }}
          className="min-w-0 flex-1 rounded-sm"
        >
          <div className="flex items-center gap-2">
            <span className="font-display text-[11px] uppercase tracking-[0.16em] text-muted">
              {AMP_LABEL[tone.ampType]} · V{tone.variation}
            </span>
            <span className="font-mono text-[11px] text-subtle">{CHANNEL_LABEL[tone.channel]}</span>
          </div>
          <h3 className="mt-1 truncate text-base font-medium text-fg">{tone.name}</h3>
          {tone.song ? (
            <p className="mt-0.5 truncate text-sm text-muted">{tone.song}</p>
          ) : null}
          <div className="mt-2.5">
            <FxChainPips fx={tone.fx} />
          </div>
        </Link>
        <div className="flex shrink-0 flex-col items-end gap-2">
          <button
            type="button"
            aria-label={tone.favorite ? "Remove favorite" : "Favorite"}
            onClick={onFav}
            className={cn(
              "relative flex size-11 items-center justify-center rounded-sm text-muted transition-colors duration-150",
              tone.favorite && "text-fg",
            )}
          >
            <Star className={cn("size-4", tone.favorite && "fill-current")} />
          </button>
          <Button size="sm" variant="secondary" onClick={onSend} disabled={sending}>
            {sending ? "Sending" : "Send"}
          </Button>
        </div>
      </div>
    </article>
  );
}
