import { FX_LABEL, FX_ORDER, type FxChain, type FxKey } from "@/lib/katana/types";
import { cn } from "@/lib/utils";

export function FxChainPips({ fx, compact }: { fx: FxChain; compact?: boolean }) {
  return (
    <div className="flex items-center gap-1">
      {FX_ORDER.map((key) => {
        const on = fx[key].on;
        return (
          <span
            key={key}
            title={`${FX_LABEL[key]}${on ? " on" : " off"}`}
            className={cn(
              "rounded-full font-display uppercase tracking-wider",
              compact
                ? "size-1.5"
                : "px-1.5 py-0.5 text-[9px]",
              on
                ? compact
                  ? "bg-led"
                  : "bg-led/20 text-fg"
                : compact
                  ? "bg-border"
                  : "bg-raised text-subtle",
            )}
          >
            {compact ? null : FX_LABEL[key]}
          </span>
        );
      })}
    </div>
  );
}

export function FxToggleRow({
  fx,
  onToggle,
}: {
  fx: FxChain;
  onToggle: (key: FxKey) => void;
}) {
  return (
    <div className="grid grid-cols-5 gap-1.5">
      {FX_ORDER.map((key) => {
        const on = fx[key].on;
        return (
          <button
            key={key}
            type="button"
            onClick={() => onToggle(key)}
            className={cn(
              "flex min-h-11 flex-col items-center justify-center gap-1.5 rounded-md px-1 transition-[background-color,box-shadow] duration-150 ease-out",
              on
                ? "bg-led/15 shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-led)_50%,transparent)]"
                : "bg-raised shadow-[0_0_0_1px_rgb(255_255_255/0.06)]",
            )}
          >
            <span className={cn("led-pip", on && "on")} />
            <span className="font-display text-[10px] uppercase tracking-[0.16em] text-fg">
              {FX_LABEL[key]}
            </span>
          </button>
        );
      })}
    </div>
  );
}
