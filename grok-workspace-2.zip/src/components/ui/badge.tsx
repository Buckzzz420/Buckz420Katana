import { cn } from "@/lib/utils";

export function Badge({
  className,
  tone = "mute",
  children,
}: {
  className?: string;
  tone?: "mute" | "led" | "ok" | "accent";
  children: React.ReactNode;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full px-2 py-0.5 text-[11px] font-medium tracking-wide uppercase",
        tone === "mute" && "bg-raised text-muted shadow-[0_0_0_1px_rgb(255_255_255/0.06)]",
        tone === "led" && "bg-led/15 text-fg",
        tone === "ok" && "bg-ok/15 text-ok",
        tone === "accent" && "bg-accent/10 text-fg",
        className,
      )}
    >
      {children}
    </span>
  );
}
