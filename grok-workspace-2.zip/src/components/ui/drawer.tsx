import { Drawer as VaulDrawer } from "vaul";
import { cn } from "@/lib/utils";

export function Drawer({
  open,
  onOpenChange,
  children,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  children: React.ReactNode;
}) {
  return (
    <VaulDrawer.Root open={open} onOpenChange={onOpenChange} shouldScaleBackground={false}>
      {children}
    </VaulDrawer.Root>
  );
}

export function DrawerContent({
  className,
  children,
  title,
}: {
  className?: string;
  children: React.ReactNode;
  title: string;
}) {
  return (
    <VaulDrawer.Portal>
      <VaulDrawer.Overlay className="fixed inset-0 z-50 bg-bg/70" />
      <VaulDrawer.Content
        className={cn(
          "fixed inset-x-0 bottom-0 z-50 mx-auto flex max-h-[92dvh] w-full max-w-lg flex-col rounded-t-xl bg-surface outline-none",
          "shadow-[0_0_0_1px_rgb(255_255_255/0.08)]",
          className,
        )}
      >
        <div className="mx-auto mt-3 h-1 w-10 rounded-full bg-border" />
        <VaulDrawer.Title className="sr-only">{title}</VaulDrawer.Title>
        <div className="overflow-y-auto px-5 pb-[max(1.5rem,env(safe-area-inset-bottom))] pt-4">
          {children}
        </div>
      </VaulDrawer.Content>
    </VaulDrawer.Portal>
  );
}
