import { Bluetooth, Cable, Radio, Usb } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Drawer, DrawerContent } from "@/components/ui/drawer";
import { bluetoothSupported, webMidiSupported } from "@/lib/katana/link";
import { useSession } from "@/lib/store";

export function ConnectSheet() {
  const open = useSession((s) => s.connectOpen);
  const setOpen = useSession((s) => s.setConnectOpen);
  const status = useSession((s) => s.status);
  const transport = useSession((s) => s.transport);
  const deviceName = useSession((s) => s.deviceName);
  const error = useSession((s) => s.error);
  const connecting = status === "connecting";

  const connectBluetooth = useSession((s) => s.connectBluetooth);
  const connectWebMidi = useSession((s) => s.connectWebMidi);
  const useSimulator = useSession((s) => s.useSimulator);

  async function run(fn: () => Promise<void>, ok: string) {
    try {
      await fn();
      toast.success(ok);
      setOpen(false);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not connect");
    }
  }

  return (
    <Drawer open={open} onOpenChange={setOpen}>
      <DrawerContent title="Connect amp">
        <p className="font-display text-xs uppercase tracking-[0.22em] text-muted">Connection</p>
        <h2 className="mt-1 text-xl font-medium">Talk to the Katana</h2>
        <p className="mt-2 text-sm text-muted">
          Hardware needs a BOSS BT-DUAL in the amp’s Bluetooth port and Chrome on Android.
          The demo amp always works in this preview.
        </p>

        <div className="mt-4 rounded-md bg-raised p-3 shadow-[0_0_0_1px_rgb(255_255_255/0.06)]">
          <div className="flex items-center gap-2 text-sm">
            <span className={transport === "simulator" ? "led-pip" : "led-pip on"} />
            <span className="font-medium">{deviceName}</span>
          </div>
          <p className="mt-1 text-xs text-muted">
            {transport === "simulator" && "Demo amp — recalls stay in the app."}
            {transport === "bluetooth" && "Bluetooth MIDI — recalling a channel hits the amp."}
            {transport === "webmidi" && "USB / Web MIDI — SysEx goes to the output."}
          </p>
          {error ? <p className="mt-2 text-xs text-led">{error}</p> : null}
        </div>

        <div className="mt-5 grid gap-2">
          <Button
            variant="primary"
            disabled={connecting || !bluetoothSupported()}
            onClick={() => run(() => connectBluetooth(false), "Katana connected over Bluetooth")}
          >
            <Bluetooth />
            Connect KATANA 3 MIDI
          </Button>
          <Button
            variant="secondary"
            disabled={connecting || !bluetoothSupported()}
            onClick={() => run(() => connectBluetooth(true), "MIDI device connected")}
          >
            <Radio />
            Scan any BLE MIDI device
          </Button>
          <Button
            variant="secondary"
            disabled={connecting || !webMidiSupported()}
            onClick={() => run(() => connectWebMidi(), "MIDI output connected")}
          >
            <Usb />
            Connect USB MIDI
          </Button>
          <Button
            variant="ghost"
            disabled={connecting}
            onClick={() => {
              useSimulator();
              toast.message("Using the demo amp");
              setOpen(false);
            }}
          >
            <Cable />
            Stay on demo amp
          </Button>
        </div>

        <ol className="mt-6 space-y-2 text-sm text-muted">
          <li>1. Fit the BT-DUAL. Power the amp. Blue LED should blink slowly.</li>
          <li>2. Enable Bluetooth on the phone. Do not pair “KATANA 3 MIDI” in system settings.</li>
          <li>3. Tap Connect above and choose KATANA 3 MIDI in the Chrome picker.</li>
          <li>4. Sending a tone recalls Panel or CH1–CH8 on the amp.</li>
        </ol>
      </DrawerContent>
    </Drawer>
  );
}
