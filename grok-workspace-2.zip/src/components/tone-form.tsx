import { AmpKnob } from "@/components/amp-knob";
import { FxToggleRow } from "@/components/fx-chain";
import { Input, Textarea } from "@/components/ui/input";
import { Field, Select } from "@/components/ui/select";
import {
  BOOSTER_TYPES,
  DELAY_TYPES,
  FX_TYPES,
  MOD_TYPES,
  REVERB_TYPES,
  TAGS,
} from "@/lib/katana/fx-catalog";
import {
  AMP_TYPES,
  AMP_LABEL,
  CHANNELS,
  CHANNEL_LABEL,
  KNOB_META,
  type AmpType,
  type Channel,
  type FxKey,
  type Knobs,
  type Tone,
  type Variation,
} from "@/lib/katana/types";
import { cn } from "@/lib/utils";

const TYPE_OPTIONS: Record<FxKey, readonly string[]> = {
  booster: BOOSTER_TYPES,
  mod: MOD_TYPES,
  fx: FX_TYPES,
  delay: DELAY_TYPES,
  reverb: REVERB_TYPES,
};

export function ToneForm({
  tone,
  onChange,
}: {
  tone: Tone;
  onChange: (patch: Partial<Tone>) => void;
}) {
  function patchKnobs(key: keyof Knobs, value: number) {
    onChange({ knobs: { ...tone.knobs, [key]: value } });
  }

  function toggleFx(key: FxKey) {
    onChange({ fx: { ...tone.fx, [key]: { ...tone.fx[key], on: !tone.fx[key].on } } });
  }

  function setFxType(key: FxKey, type: string) {
    onChange({ fx: { ...tone.fx, [key]: { ...tone.fx[key], type } } });
  }

  function toggleTag(tag: string) {
    const has = tone.tags.includes(tag);
    onChange({ tags: has ? tone.tags.filter((t) => t !== tag) : [...tone.tags, tag] });
  }

  return (
    <div className="grid gap-6">
      <Field label="Name">
        <Input value={tone.name} onChange={(e) => onChange({ name: e.target.value })} />
      </Field>
      <Field label="Song / use">
        <Input
          value={tone.song}
          placeholder="Where this tone lives"
          onChange={(e) => onChange({ song: e.target.value })}
        />
      </Field>
      <Field label="Notes">
        <Textarea
          value={tone.notes}
          placeholder="Pickup, capo, extra stomps…"
          onChange={(e) => onChange({ notes: e.target.value })}
        />
      </Field>

      <div className="grid grid-cols-2 gap-3">
        <Field label="Amp type">
          <Select
            value={tone.ampType}
            onChange={(e) => onChange({ ampType: e.target.value as AmpType })}
          >
            {AMP_TYPES.map((a) => (
              <option key={a} value={a}>
                {AMP_LABEL[a]}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Variation">
          <Select
            value={String(tone.variation)}
            onChange={(e) => onChange({ variation: Number(e.target.value) as Variation })}
          >
            <option value="1">Variation 1</option>
            <option value="2">Variation 2</option>
          </Select>
        </Field>
      </div>

      <Field label="Amp memory">
        <Select
          value={String(tone.channel)}
          onChange={(e) => onChange({ channel: Number(e.target.value) as Channel })}
        >
          {CHANNELS.map((ch) => (
            <option key={ch} value={ch}>
              {CHANNEL_LABEL[ch]}
            </option>
          ))}
        </Select>
      </Field>

      <div>
        <p className="mb-3 font-display text-[11px] uppercase tracking-[0.16em] text-muted">Panel knobs</p>
        <div className="flex gap-1 overflow-x-auto pb-1">
          {KNOB_META.map((k) => (
            <AmpKnob
              key={k.key}
              label={k.label}
              value={tone.knobs[k.key]}
              onChange={(v) => patchKnobs(k.key, v)}
            />
          ))}
        </div>
      </div>

      <div>
        <p className="mb-3 font-display text-[11px] uppercase tracking-[0.16em] text-muted">Effects</p>
        <FxToggleRow fx={tone.fx} onToggle={toggleFx} />
        <div className="mt-3 grid gap-3">
          {(["booster", "mod", "fx", "delay", "reverb"] as FxKey[]).map((key) => (
            <Field key={key} label={`${key} type`}>
              <Select value={tone.fx[key].type} onChange={(e) => setFxType(key, e.target.value)}>
                {TYPE_OPTIONS[key].map((opt) => (
                  <option key={opt} value={opt}>
                    {opt}
                  </option>
                ))}
              </Select>
            </Field>
          ))}
          {tone.fx.delay.on ? (
            <Field label="Delay time (ms)">
              <Input
                type="number"
                min={20}
                max={2000}
                value={tone.fx.delay.timeMs}
                onChange={(e) =>
                  onChange({
                    fx: {
                      ...tone.fx,
                      delay: { ...tone.fx.delay, timeMs: Number(e.target.value) || 0 },
                    },
                  })
                }
              />
            </Field>
          ) : null}
        </div>
      </div>

      <div>
        <p className="mb-2 font-display text-[11px] uppercase tracking-[0.16em] text-muted">Tags</p>
        <div className="flex flex-wrap gap-1.5">
          {TAGS.map((tag) => {
            const on = tone.tags.includes(tag);
            return (
              <button
                key={tag}
                type="button"
                onClick={() => toggleTag(tag)}
                className={cn(
                  "h-9 rounded-full px-3 text-sm transition-colors duration-150",
                  on ? "bg-accent text-accent-fg" : "bg-raised text-muted",
                )}
              >
                {tag}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
